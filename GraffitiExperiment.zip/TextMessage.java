import java.util.Vector;

/** TextMessage - a class for a text message.  
*
* Used by, for example, <code>PhoneKeypad</code> (do not delete).
* 
* @see <a href="TestMessage.java">source code</a>
* @author Scott MacKenzie, 2008
*/
public class TextMessage 
{
   private Vector<String> message = new Vector<String>();

   /** constructor
   */
   TextMessage()
   { //message(); 
	}

   /** Returns the text message as a string.
   */
   public String getMessage()
   {
      String s = "";

      if (message.size() == 0)
         return "";

      for (int i = 0; i < message.size() - 1; ++i)
         s = s + message.elementAt(i) + " ";
      s += message.elementAt(message.size() - 1); // no space after last word
      return s;
   }

   /** Returns the size of the text message, in characters.
   */
   public int getSize()
   { return this.getMessage().length(); }

   /** Returns the number of words in the text message.
   */
   public int getWordCount()
   { return message.size(); }

   /** Returns the character at position i.
   */
   public int getCharacter(int i)
   { return this.getMessage().charAt(i); }

   /** Returns message as series of codes (as per phone keypad).
   */
   public String getCodedMessage()
   {
      String cm = "";
      String s = "";
      int i = 0;
      while (i < message.size() - 1)
      {
         s = message.elementAt(i);
         cm = cm + EncodedWord.encodeWord(s) + " ";
         ++i;
      }
      s = message.elementAt(i); // no space after last code
      cm += EncodedWord.encodeWord(s);
      return cm;
   }

   /** Add word to end of text message.
   */
   public void addWord(String s) 
   { message.addElement(s); }

   /** Replace last word in message with passed word.
   *
   * If no message, add passed word.
   */
   public void replaceLast(String s)
   {
      if (message.size() > 0)
      {
         message.removeElementAt(message.size() - 1);
      }
      message.addElement(s);
      return;
   }

   /** Appends a character to the last word in the text message.
   */
   public void appendCharacter(char c)
   {
      String last = message.elementAt(message.size()) + c;
      message.removeElementAt(message.size() - 1);
      message.addElement(last);
   }

   /** Clear the text message.
   */
   public void clear()
   { message.clear(); }

   /** Print the text message on the console.
   */
   public void printMessage()
   {  System.out.println(this.getMessage()); }

   /** Test the TextMessage class.
   */
   public static void main(String[] args)
   {
      String[] test = { "the", "quick", "brown", "fox" };

      System.out.println("create a text message (empty)");
      TextMessage tm = new TextMessage();
      System.out.println("words: " + tm.getWordCount() +
               ", characters: " + tm.getSize());

      System.out.println("Print stats and add a few words");
      for (int i = 0; i < test.length; ++i)
      {
         System.out.println("adding \'" + test[i] + "\'...");
         tm.addWord(test[i]);
         tm.printMessage();
         System.out.println("words: " + tm.getWordCount() +
               ", characters: " + tm.getSize());
      }

      System.out.println("\nPrint message as words and codes...");
      tm.printMessage();
      System.out.println(tm.getCodedMessage());

      System.out.println("\nTest replaceLast() method...");
      System.out.println("Replace last word with \'turtle\'");
      tm.replaceLast("turtle");
      System.out.print("Message: ");
      tm.printMessage();
   }
}

