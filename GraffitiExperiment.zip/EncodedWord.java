import java.io.*;
import java.util.*;
import javax.swing.*;

/** A class for words encoded as (a) a <code>String</code> representing the word,
* (b) an <code>int</code> representing the frequency of the word in the target
* language, and (c) a <code>String</code> representing
* the numeric code for the word, as per
* the telephone keypad.
*
* @author Scott MacKenzie, 2001-2014
* @author Steven Castellucci, 2014 (added GUI error messages)
*/
public class EncodedWord extends Word
{

   private static final int MAX = 100;
   private String code;

   /** Construct an <code>EncodedWord</code> object.
   *
   * If only the word and its frequency are passed as arguments.
   * the code field is initialized as per a phone keypad.  For example,
   * the word "lazy" is assigned the code "5299".
   *
   * @param s a <code>String</code> representing a word.
   * @param n an <code>int</code> representing the frequency of the word
   * in the language.
   */
   public EncodedWord(String s, int n)
   {
      super(s, n);
      code = encodeWord(s);
   }

   /** Construct an <code>EncodedWord</code> object.
   *
   * If a code is also passed as an argument, it will be use for
   * the code field of the EncodedWord.  For example, for T9 encoding,
   * the code "5299N" might be used for the word "lazy", or, for
   * Multitap encoding, the code "55529999N999" might be used.
   *
   * @param s a <code>String</code> representing a word.
   * @param n an <code>int</code> representing the frequency of the word
   * in the language.
   * @param cde a <code>String</code> representing the code for the word
   * for the interaction technique of interest.
   */
   public EncodedWord(String s, int n, String cde)
   {
      super(s, n);
      code = cde;
   }

   /** Construct an <code>EncodedWord</code> object.
   *
   * If only word is passed, the frequency is initialized with zero, and
   * the code is initialized as per the phone keypad.  For example,
   * "lazy" is initialized with frequency = 0, and code = "5299".
   *
   * @param s a <code>String</code> representing a word.
   */
   public EncodedWord(String s)
   {
      super("", 0);
      code = s;
   }

   /** Returns a <code>String</code>
   * representing the word portion of this <code>EncodedWord</code>.
   */
   public String getWord() { return super.word; }

   /** Returns an <code>int</code> representing the frequency
   * of this <code>EncodedWord</code>.
   */
   public int getFreq() { return super.freq; }

   /** Returns a <code>String</code> representing the code
   * for this <code>EncodedWord</code>.
   */
   public String getCode() { return code; }

   /** Assigns a <code>code</code> to this this <code>EncodedWord</code>.
   *
   * @param cde a <code>String</code> representing the code to assign
   * to this EncodedWord.  For example the code "5299N" might be used
   * to assign the standard T9 code to the word "lazy".
   */
   public void setCode(String cde)
   {
      code = cde;
   }

   /** Returns a String representation of this EncodedWord
   */
   public String toString()
   { return super.word + " " + code + " " + super.freq; }

   /** Encode a word as per a phone keypad.
   *
   * The argument is assumed to contain only letters.  Non letters
   * are encoded as '#'.  A space is returned as a space.
   *
   * @param s1 a <code>String</code> representing a word (or phrase) to encode
   * @return a <code>String</code> representing the word encoded as per a
   * phone keypad.  For example "lazy" is returned as "5299".
   */
   public static String encodeWord(String s1)
   {
      String s2 = "";
      for (int i = 0; i < s1.length(); ++i)
      {
         char c = Character.toLowerCase(s1.charAt(i));
         s2 = s2 + encodeLetter(c);
      }
      return s2;
   }

   /** Encode a character as per a phone keypad.
   *
   * @param c a <code>char</code> to encode
   * @return a <code>char</code> representing the numeric key on a phone
   * keypad representing the given character.  For example, 'f' is returned
   * as '3'.
   */
   public static char encodeLetter(char c)
   {
      //if (c == 'a' || c == 'b' || c == 'c') return '2';
      //if (c == 'd' || c == 'e' || c == 'f') return '3';
      //if (c == 'g' || c == 'h' || c == 'i') return '4';
      //if (c == 'j' || c == 'k' || c == 'l') return '5';
      //if (c == 'm' || c == 'n' || c == 'o') return '6';
      //if (c == 'p' || c == 'q' || c == 'r' || c == 's') return '7';
      //if (c == 't' || c == 'u' || c == 'v') return '8';
      //if (c == 'w' || c == 'x' || c == 'y' || c == 'z') return '9';
      //if (c == ' ') return ' ';
      //return '#';

      return keys.charAt(alphabet.indexOf(c));
   }

   /** Load a coded dictionary file into an <code>EncodedWord</code> array.
   *
   * A coded dictionary file contains a series of lines, each containing
   * three white-space delimited entries: a word, the frequency
   * of the word in the target language, and the code (viz. keystrokes)
   * used to entered the word using the intended interaction technique.<p>
   *
   * As an example of a dictionary file, here are the first few lines from
   * the file <code>d1-wordfreq-ks.txt</code>:<p>
   *
   * <pre>
   *     the   5776384   843
   *     of    2789403   63
   *     and   2421302   263
   *     a     1939617   2
   *     in    1695860   46
   *     to    1468146   86
   * </pre>
   *
	* After loading the dictionary, the entries are sorted "by code" in ascending
	* order.<p>
	*
   * @param fileName the name of the coded dictionary file
   * @return a <code>EncodedWord</code> array.
   *
   */
   public static EncodedWord[] loadCodedDictionary(String fileName) throws IOException
   {
      // ensure dictionary file exists
      File f = new File(fileName);
      if (!f.exists())
      {
         System.out.println("File not found - " + fileName);
         showError("File not found - " + fileName);
         System.exit(1);
      }

      // open dictionary file for input
      BufferedReader inputFile =
         new BufferedReader(new FileReader(fileName));

      // read lines from coded dictionary ('word frequency code' on each line)
      String line;
      Vector<EncodedWord> v = new Vector<EncodedWord>();
      while ((line = inputFile.readLine()) != null)
      {
         StringTokenizer st = new StringTokenizer(line);

         // exactly two entries per line required
         if (st.countTokens() != 3)
         {
            System.out.println("Dictionary format error");
            System.out.println("line=" + line);
            showError("Dictionary format error on line " + line);
            System.exit(1);
         }

         // get the word, frequency, and code
         String newWord = st.nextToken();
         int newFreq = Integer.parseInt(st.nextToken());
         String newCode = st.nextToken();

         // add to vector as a EncodedWord object
         v.addElement(new EncodedWord(newWord, newFreq, newCode));
      }

      // close disk file
      inputFile.close(); 

      // declare an EncodedWord array of just the size needed
      EncodedWord[] dict = new EncodedWord[v.size()];

      // copy elements from vector into array
      v.copyInto(dict);

      // sort the dictionary by code
      Arrays.sort(dict, new ByCode());
      return dict;
   }

   private static void showError(String msg)
   {
      JOptionPane.showMessageDialog(null, msg, "I/O Error", JOptionPane.ERROR_MESSAGE);
   }

   /** Returns an array of words (sorted by frequency) matching the
   * given code.<p>
   *
   * @param code a String representing a word encoded as per the
   * telephone keypad (e.g., "5299")
   * @param dict an array of EncodedWord objects (i.e., a dictionary)
   * @return a string array of words matching the code.  The array
   * is ordered with the most probable matches first.  For example, if
   * code = "5299", { "jazz", "lazy" } is returned.  Returns a 
   * <code>null</code> reference if no matches.<p>
   */
   public static String[] getUnique(String code, EncodedWord[] dict)
   {
      String[] words = null;

      // no matches if no code!
      if (code == "")
         return words;

      // find lower bracketing index (n1)
      int n1 = Arrays.binarySearch(dict, new EncodedWord(code), new ByCode());

      // no matches if return value < 0
      if (n1 < 0)
         return words;  // no matches

      // because codes are not unique, backup index if necessary
      while (n1 > 0 && dict[n1].getCode().compareTo(dict[n1 - 1].getCode()) == 0)
         --n1;

      // s2 is 1st entry 'after' entries matching code 
      //String s2 = code + "0";

      // find upper bracketing index (n2)
      //int n2 = Arrays.binarySearch(dict, new EncodedWord(s2), new ByCode());

      // is no match for s2, that's OK; need a +ve index anyway
      //if (n2 < 0)
      //   n2 = -n2 - 1;

		// find upper bracketing index (new way!)
		int n2 = n1;
		while (n2 < dict.length && dict[n1].getCode().equals(dict[n2].getCode()))
			++n2;

      // make a new Word array for all choices (and there are some!)
      EncodedWord[] ew = new EncodedWord[n2 - n1];
      int i, j;
      for (i = n1, j = 0; i < n2; i++, j++)
         ew[j] = dict[i];

      // sort the new array by frequency
      Arrays.sort(ew, new WordByFreq());
 
      // make a String array for just the words
      words = new String[ew.length];  
      for (i = 0; i < words.length; ++i)
         words[i] = ew[i].getWord();
      return words;
   }

   /** Returns a String array (sorted by frequency) 
   * containing words tentatively matching the given code.<p>
   *
   * @param code a String representing a word encoded as per the telephone
   * keypad
   * @param dict an array of EncodedWord objects (i.e., the dictionary)
   * @return a string array of words tentatively matching the code.
   * "Tentative" implies that the words
   * in the returned array begin with a pattern of letters
   * matching the given code. For
   * example, if code = "5299", the returned array might be { "laywers",
   * "lawyer", "lazy", "jazz" }
   */
   public static String[] getTentative(String code, EncodedWord[] dict)
   {
      String[] words = null;

      // no matches if no code!
      if (code == "")
         return words;

      // find position in array of code entered and s2
      int n1 = Arrays.binarySearch(dict, new EncodedWord(code), new ByCode());

      // no matches (insertion points in middle, it is a word)
      if (n1 < 0)
         n1 = -n1 - 1;

      // no matches (insertion point at end, it is not a word)
      if (n1 >= dict.length)
         return words;

      // find lower bracketing index
      while (n1 > 0)
      {
         String s = dict[n1 - 1].getCode();

         if (s.length() < code.length())
            break;
         s = s.substring(0, code.length());
         if (s.compareTo(code) == 0)
            --n1;
         else
            break;         
      }

      // find upper bracketing index
      int n2 = n1;
      while (n2 < dict.length)
      {
         String s = dict[n2].getCode();

         if (s.length() < code.length())
            break;

         s = s.substring(0, code.length());
         if (s.compareTo(code) == 0)
            ++n2;
         else
            break;
      }

      // it is not a word, and there are no tentative matches
      if (n1 == n2)
         return words;

      // make an EncodedWord array containing all tentative matches
      EncodedWord[] ew = null;
      ew = new EncodedWord[n2 - n1];
      int i, j;
      for (i = n1, j = 0; i < n2; i++, j++)
         ew[j] = dict[i];

      // sort the array by frequency
      Arrays.sort(ew, new WordByFreq());

      // might be absurdly big, limit size to MAX
      int n = ew.length > MAX ? MAX : ew.length;

      // copy only the words into a string array
      words = new String[n];
      for (i = 0; i < n; ++i)
         words[i] = ew[i].getWord();

      // success!
      return words;
   }

	/** Returns a string array of the highest-frequency words in an
	* EncodedWord dictionary.  The returned string array is sorted
	* in descending order with the highest frequency word first.
	*
	* @param n the number of words to return
	* @param dict an array of EncodedWord objects
	* @return a String array (e.g., { "the", "of", "and" } )
	*/
	public static String[] getMostFrequent(int n, EncodedWord[] dict)
	{
		EncodedWord[] ew = new EncodedWord[dict.length];
		for (int i = 0; i < ew.length; ++i)
			ew[i] = dict[i];
		Arrays.sort(ew, new WordByFreq());

		String[] s = new String[n];
		for (int i = 0; i < s.length; ++i)
			s[i] = ew[i].getWord();
		return s;
	}

   /** Returns a string array containing a query.
   *
   * Returns <code>null</code> if no entries in query.
   * A query consists of an array of words beginning
   * with those returned by <code>getUnique()</code>, followed by those
   * returned by <code>getTentative()</code>.  Duplicates are
   * removed.
   *
   * @param code a String containing the numeric code for a word
   * (e.g., "5299")
   * @param dict an array of EncodedWord objects
   * @return a String array (e.g., { "jazz", "lazy" } )
   */
   public static String[] getQuery(String code, EncodedWord[] dict)
   {
      String[] query = null;

      // no query if no code!
      if (code == "")
         return query;

      String[] unique = getUnique(code, dict);
      String[] tentative = getTentative(code, dict);

      // coming up empty
      if (unique == null && tentative == null)
         return query;

      // only tenative matches, return them
      if (unique == null && tentative != null)
         return tentative;

      // only unique matches, return them
      if (unique != null && tentative == null)
         return unique;

      // OK, we've got a combination of unique and tentative matches

      // first, put the unique matches into a vector
      Vector<String> v = new Vector<String>();
      //for (int i = 0; i < unique.length; ++i)
      //   v.addElement(unique[i]);
		for(String s : unique) // using for:each construction
			v.addElement(s);

      // then add the tenative matches to the end, omitting duplicates
      for (int i = 0; i < tentative.length; ++i)
      {
         if (!v.contains(tentative[i]))
            v.addElement(tentative[i]);
      }

      // make a query array of just the size needed
      query = new String[v.size()];

      // copy the results into the query array
      v.copyInto(query);

      // success!
      return query;
   }

   /** Prints an array of EncodedWord objects.
   *
   * @param ew an array of EncodedWord objects
   */
   public static void printEncodedWord(EncodedWord[] ew)
   {
      for (int i = 0; i < ew.length; ++i)
         System.out.println(ew[i]);
   }

   /** Print a string array.
   */
   public static void printStringArray(String[] s)
   {
      if (s == null)
         System.out.println("sorry!");
      else
      {
         for (int i = 0; i < s.length; ++i)
            System.out.print(s[i] + " ");
         System.out.println();
      }
   }

   private static String alphabet =   "abcdefghijklmnopqrstuvwxyz��";
   private static String keys =       "2223334445556667777888999926";
   private static String keystrokes = "1231231231231231234123123455";

   /** Return a string containing the Multitap code (i.e., keystrokes) for
   * the given word.
   *
   * @param word a word to encode as per Multitap keystrokes.
   * @return a string containing the Multitap keytrokes required to
   * enter the given word.
   */
   public static String encodeWordMultitap(String word)
   {
      String ks = "";
      for (int i = 0; i < word.length(); ++i)
      {
         // get character (convert to lowercase, if necessary)
         char c = Character.toLowerCase(word.charAt(i));

         // determine the number of times the key must be pressed
         int repeats = keystrokes.charAt(alphabet.indexOf(c)) - '0';
         for (int j = 0; j < repeats; ++j)
            ks += "" + keys.charAt(alphabet.indexOf(c));

         // see if a press of NEXT is necessary
         if (i < word.length() - 1)
         {
            char cNext = Character.toLowerCase(word.charAt(i + 1));
            int a = keys.charAt(alphabet.indexOf(c));
            int b = keys.charAt(alphabet.indexOf(cNext));
            if (a == b)
               ks += "N";
         }
      }
      return ks;
   }

   /** Test the EncodedWord class.
   */
   public static void main(String[] args) throws IOException
   {
      // one command line argument needed
      if (args.length == 0 || args.length > 2)
      {
         System.out.println("usage: java EncodedWord dictionary");
         return;
      }

      EncodedWord[] ew;
      System.out.print("Load and sort coded dictionary...");
      ew = EncodedWord.loadCodedDictionary(args[0]);
      System.out.println("(done)");
      System.out.println("Coded dictionary contains " + ew.length + " words");

      BufferedReader stdin =
         new BufferedReader(new InputStreamReader(System.in), 1);

      System.out.println("*** Test the 'encode' methods ***");
      System.out.println("Enter a word...");
      String wrd = stdin.readLine();
      System.out.println("Phone keypad code: " + encodeWord(wrd));
      System.out.println("Multitap code: " + encodeWordMultitap(wrd));

		System.out.println("*** Text the getMostFrequeny method ***");
		System.out.println("10 most frequent words in dictionary...");
		String[] top10 = getMostFrequent(10, ew);
		for (String tmp: top10)
			System.out.print(tmp + " ");
		System.out.println();

      System.out.println("*** Test the get methods ***");
      System.out.println("Enter codes... (^z to exit)");
      // process lines until no more input
      String code;
      while ((code = stdin.readLine()) != null)
      {
         String[] s;

         s = getUnique(code, ew);
         System.out.println("\nResults of getUnique()...");
         //System.out.println("unique = " + s);
         printStringArray(s);

         s = getTentative(code, ew);
         System.out.println("\nResults of getTentative()...");
         //System.out.println("tentative = " + s);
         printStringArray(s);

         s = getQuery(code, ew);
         System.out.println("\nResults of getQuery()...");
         //System.out.println("query = " + s);
         printStringArray(s);
      }
   }
}

/*class ByCode implements Comparator<EncodedWord>
{
   public int compare(EncodedWord ew1, EncodedWord ew2)
   {
      String s1 = ew1.getCode();
      String s2 = ew2.getCode();
      return s1.compareTo(s2);
   }
}*/