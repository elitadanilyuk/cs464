import java.util.*;

public class WordByWord implements Comparator<Word>
{
   public int compare(Word w1, Word w2)
   {
		String s1 = w1.getWord();
		String s2 = w2.getWord();
      return s1.compareTo(s2);
   }
}
