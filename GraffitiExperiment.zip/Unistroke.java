import java.awt.*;
import java.io.*;
import java.util.*;

/** A class for performing character recognition on unistrokes.<p>
*
* A "unistroke" is a set of <I>x-y</I> sample points created in a single
* gesture with a stylus or finger on a digitizing surface.<p>
*
* Applications using the <code>Unistroke</code> class generally need
* to instantiate only one <code>Unistroke</code> object.
* Thereafter, all processing, such as character recognition,
* loading custom dictionaries, and switching between the built-in
* and custom dictionaries, may be performed through this object
* via the fields
* and instance methods of the <code>Unistroke</code> class.<p>
*
* The <code>Unistroke</code> class includes three built-in dictionaries
* (<code>graffiti, unistrokes, digits</code>) and support for up to
* five custom dictionaries.<p>
*
* The process of recognition involves computing the "features" of a stroke
* and then comparing them with the features in the dictionary to find a match.
* <p>
*
* <h3>Dictionary Description</h3><p>
*
* Each row in the dictionary contains thirteen (13) values
* delimited by spaces or commas.  As well, a dictionary
* may include comment lines beginning with "<code>#</code>"
* (hash symbol), or blank lines.  These are ignored.<p>
*
* The thirteen values consist
* of the recognized character(s) for the entry (<code>symbol</code>) followed by
* twelve stroke "features".  These consist of four 
* values representing the stroke's transition through "quadrants"
* of a bounding box (<code>quadf, quads, quadsl, quadl</code>),
* four values representing the cumulative distance of the stroke
* along the <I>x</I> and <I>y</I> axes (<code>kxmin, kxmax, kymin, kymax</code>), and
* four values representing the starting and terminating directions
* of the stroke along the <I>x</I> and <I>y</I> axes (<code>startx, starty, stopx,
* stopy</code>).<p>
*
* In calculating the features in a stroke, the sample points
* are first normalized to fit within a unit bounding box.
* The bounding box is divided into four quadrants, "0" at the
* top right, "1" at the lower right, "2" at the lower left, and
* "3" at the upper left:<p>
*
* <center><img src = "Unistroke-BoundingBox.jpg"></center><p>
*
* Besides these four values, a dictionary entry may contain the
* value "4", implying "don't care".  In this case, the
* recognizer will not check the corresponding quadrant feature
* in the current stroke.<p>
*
* The dictionary entries are described in greater detail below.<p>
*
* <code>symbol</code>
* is the string the recognizer returns if the features in
* the current stroke match the defined values in a particular row of the
* dictionary.<p>
*
* By convention, "=string"
* is used for strokes which are recognized, but for which no particular
* character is assigned by the recognizer.  For these strokes, the
* application is expected to provide an appropriate interpretation.
* For example,
*
* <pre>
*     =SW for a straight-line stroke in a south west direction
*     =CR for a stroke intended to represent a carriage return
* </pre>
*
* Since the recognizer returns a string, not a character, it is
* possible to define "shorthand" strokes &mdash; single strokes that
* return a complete word or phrase.  These may be defined in
* the "home" dictionary, or in a dedicated mode-shift dictionary.
* A mode-shift dictionary is a dictionary invoked through a dedicate
* mode-shift stroke in the "home" dictionary (much like the
* "symbol shift" stroke in graffiti).<p>
*
* <code>quadf</code>
* is an integer representing the required <u>first
* quadrant</u> for the stroke.
* <p>
*
* <code>quads</code>
* is an integer representing the required <u>second
* quadrant</u> for the stroke.
* <p>
*
* <code>quadsl</code>
* is an integer representing the required <u>second last
* quadrant</u> for the stroke.
* <p>
*
* <code>quadl</code>
* is an integer representing the required <u>last
* quadrant</u> for the stroke.
* <p>
*
* Each stroke's "cumulative" distance features are
* calculated in the recognizer
* by summing the absolute distances between successive pairs of sample
* points along both the <I>x</I> and <I>y</I> axes.<p>
*
* The calculation is performed on the "normalized" sample points;
* that is, on the sample points after they 
* are scaled to fit within a "unit bounding box" (width = 1,
* height = 1).<p>
*
* For example, a Graffiti "a", if entered perfectly,
* will have a cumulative <I>x</I> distance of 1 unit and a cumulative <I>y</I> distance
* of 2 units:<p>
*
* <center><img src = "Unistroke-Alphabet-Graffiti-A.jpg"></center><p>
*
* Similarly, a graffiti "z", if entererd perfectly,
* will have a cumulative <I>x</I> distance of 3 units and a cumulative <I>y</I>
* distance of 1 unit:<p>
*
* <center><img src = "Unistroke-Alphabet-Graffiti-Z.jpg"></center><p>
*
* Obviously, users to do not enter their strokes "perfectly".
* For a stroke to be recognized, the calculated
* cumulative distance features must fall within the minimum
* and maximum values (inclusive) in the
* stroke dictionary. These values may be specified as reals (e.g., 2.1).<p>
*
* Thus, the four cumulative distance values in the dictionary
* are defined as follows.<p>
* <p>
*
* <code>kxmin</code>
* represents the required
* <u>minimum cumulative <I>x</I> distance</u> for the stroke
* <p>
*
* <code>kxmax</code>
* represents the required
* <u>maximum cumulative <I>x</I> distance</u> for the stroke
* <p>
*
* <code>kymin</code>
* represents the required
* <u>minimum cumulative <I>y</I> distance</u> for the stroke
* <p>
*
* <code>kxmax</code>
* represents the required
* <u>maximum cumulative <I>y</I> distance</u> for the stroke
* <p>
*
* The last four dictionary values represent the starting and
* terminating direction of the stroke.  In the
* recognizer, these are computed on the first and last
* 25% of the samples.  The computed
* value is either 0 or 1, where "0" implies motion
* to the left along the <I>x</I> axis or downward
* along the <I>y</I> axis,
* and "1" implies motion to the right along the <I>x</I>
* axis or upward along the <I>y</I> axis.<p>
*
* For example, the stroke for a graffiti "a" should begin with
* motion "to the right" along the <I>x</I> axis and motion "up"
* along the <I>y</I> axis.  It should terminate with motion
* "to the right" along the <I>x</I> axis and motion "down" along
* the <I>y</I> axis:<p>
*
* <center><img src = "Unistroke-StartStopXY.jpg"></center><p>
*
* Depending on the desired stroke shape, the
* corresponding dictionary entries should be either 0 or 1.  As well,
* "4" may appear in the dictionary as a "don't care" condition.
* In this case, the recognizer does not check 
* the stroke's corresponding feature.<p>
*
* The four direction values are as follows.<p>
*
* <code>startx</code>
* is an integer representing the required
* <u>starting x direction</u> for the stroke
* <p>
*
* <code>starty</code>
* is an intteger representing the required
* <u>starting y direction</u> for the stroke
* <p>
*
* <code>stopx</code>
* is an integer> representing the required
* <u>terminating x direction</u> for the stroke
* <p>
*
* <code>stopy</code>
* is an integer representing the required
* <u>terminating y direction</u> for the stroke
* <p>
*
* @author Scott MacKenzie, 2001-2011
*/
public class Unistroke 
{
   private final int TAP_THRESHHOLD = 5;
   private final double ASPECT_RATIO = 0.2;
   private final String UNDEFINED_STROKE = "#";

   /** A constant identifying a custom stroke dictionary.<p>
   *
   * The <code>Unistroke</code> class supports up to five custom
   * dictionaries.  They may be changed
   * on-the-fly using the <code>setDictionary()</code> method with this
   * field as an argument.
   * <p>
   * @see #setDictionary
   * @see #loadDictionary
   */
   public static final int CUSTOM1 = 1;

   /** A constant identifying a custom stroke dictionary.<p>
   *
   * The <code>Unistroke</code> class supports up to five custom
   * dictionaries.  They may be changed
   * on-the-fly using the <code>setDictionary()</code> method with this
   * field as an argument.
   * <p>
   * @see #setDictionary
   * @see #loadDictionary
   */
   public static final int CUSTOM2 = 2;

   /** A constant identifying a custom stroke dictionary.<p>
   *
   * The <code>Unistroke</code> class supports up to five custom
   * dictionaries.  They may be changed
   * on-the-fly using the <code>setDictionary()</code> method with this
   * field as an argument.
   * <p>
   * @see #setDictionary
   * @see #loadDictionary
   */
   public static final int CUSTOM3 = 3;

   /** A constant identifying a custom stroke dictionary.<p>
   *
   * The <code>Unistroke</code> class supports up to five custom
   * dictionaries.  They may be changed
   * on-the-fly using the <code>setDictionary()</code> method with this
   * field as an argument.
   * <p>
   * @see #setDictionary
   * @see #loadDictionary
   */
   public static final int CUSTOM4 = 4;

   /** A constant identifying a custom stroke dictionary.<p>
   *
   * The <code>Unistroke</code> class supports up to five custom
   * dictionaries.  They may be changed
   * on-the-fly using the <code>setDictionary()</code> method with this
   * field as an argument.
   * <p>
   * @see #setDictionary
   * @see #loadDictionary
   */
   public static final int CUSTOM5 = 5;

   /** A constant identifying the built-in "graffiti"
   * stroke dictionary.<p>
   *
   * Use as an argument to the <code>setDictionary()</code> method.<p>
   *
   * The graffiti alphabet is shown below:<p>
   *
   * <center><img src = "Unistroke-Alphabet-Graffiti.jpg"></center>
   * 
   * <p>
   * @see #setDictionary
   */
   public static final int GRAFFITI = 6;

   /** A constant identifying the built-in "unistrokes"
   * stroke dictionary.<p>
   *
   * Use as an argument to the <code>setDictionary()</code> method.<p>
   *
   * Note: "unistrokes" is this sense implies the stroke alphabet
   * presented in the paper "Touch typing with a stylus" by
   * D. Goldberg and C. Richardson, published in the <i>Proceedings
   * of INTERCHI '93</i>, pp. 80-87.
   * This is the original "unistrokes" paper.<p>
   *
   * The unistrokes alphabet is shown below:<p>
   *
   * <center><img src = "Unistroke-Alphabet-Unistrokes.jpg"></center>
   * <p>
   * @see #setDictionary
   */
   public static final int UNISTROKES = 7;

   /** A constant identifying the built-in "digits"
   * stroke dictionary.<p>
   *
   * Use as an argument to the <code>setDictionary()</code> method.<p>
   *
   * The digits alphabet is shown below:<p>
   *
   * <center><img src = "Unistroke-Alphabet-Digits.jpg"></center>
   * <p>
   * @see #setDictionary
   */
   public static final int DIGITS = 8;

   /** Load a custom dictionary from a disk file.
   * After loading, the custom dictionary becomes the currently active
   * dictionary.<p>
   *
   * @param s the name of the disk file containing the stroke definitions.
   * @param n an integer representing the dictionary (e.g.,
   * <code>Unistroke.CUSTOM1</code>).  This argument is used later with the
   * <code>setDictionary()</code> method to switch from one
   * dictionary to another.
   * @return <code>true</code> if the load was successful, <code>false</code>
   * otherwise.
   */
   public boolean loadDictionary(String s, int n) 
   {
      // attempt to open disk file for input
      BufferedReader inFile;
      try
      {
         inFile = new BufferedReader(new FileReader(s));
      }
      catch (FileNotFoundException e)
      {
         System.out.println("Can't find dictionary file: " + s);
         return false;
      }

      // we'll use a vector to collect the dictionary items
      Vector<StrokeDef> v = new Vector<StrokeDef>();

      String line;
      boolean moreData = true;
      while (moreData)
      {
         // try/catch for readLine()
         try
         {
            line = inFile.readLine();
         }
         catch (IOException e)
         {
            System.out.println("IOException error reading dictionary file");
            return false;
         }

         if (line == null)
         {
            moreData = false;
            continue;
         }
       
         // ignore blank lines
         if (line.length() == 0)
            continue;

         // ignore comments lines ("#" in 1st position)
         if (line.length() > 0 && line.substring(0, 1).equals("#"))
            continue;

         StringTokenizer st = new StringTokenizer(line, ", ");

         // ignore blank lines with spaces
         if (st.countTokens() == 0)
            continue;

         if (st.countTokens() != 13)
         {
            System.out.println("Data format error in file: " + s);
            System.out.println("... data: " + line);
            System.out.println("... token count: " + st.countTokens());
            System.out.println("... line length: " + line.length());
            return false;
         }

         StrokeDef sd = new StrokeDef(
            st.nextToken(),
            Integer.parseInt(st.nextToken()),
            Integer.parseInt(st.nextToken()),
            Integer.parseInt(st.nextToken()),
            Integer.parseInt(st.nextToken()),
            Double.parseDouble(st.nextToken()),
            Double.parseDouble(st.nextToken()),
            Double.parseDouble(st.nextToken()),
            Double.parseDouble(st.nextToken()),
            Integer.parseInt(st.nextToken()),
            Integer.parseInt(st.nextToken()),
            Integer.parseInt(st.nextToken()),
            Integer.parseInt(st.nextToken())    );
        v.add(sd);
      }

      // create a StrokeDef array of just the size needed
      custom1 = new StrokeDef[v.size()];

      // copy vector contents into array
      v.copyInto(custom1);

      // make this the active dictionary
      setDictionary(n);

      return true;
   }

   // digits stroke dictionary
   private static StrokeDef[] dsd = 
   {
      new StrokeDef("=N", 1,  4,  4,  0,  0.0, 0.0, .98,  1.0,   4,   4,   4,   4 ),
      new StrokeDef("=N", 2,  4,  4,  0,  0.0, 0.0, .98,  1.0,   4,   4,   4,   4 ),
      new StrokeDef("=N", 1,  4,  4,  3,  0.0, 0.0, .98,  1.0,   4,   4,   4,   4 ),
      new StrokeDef("=N", 2,  4,  4,  3,  0.0, 0.0, .98,  1.0,   4,   4,   4,   4 ),
                                                           
      new StrokeDef("1", 0,  4,  4,  1,  0.0, 0.0, .98,  1.0,   4,   4,   4,   4 ),
      new StrokeDef("1", 3,  4,  4,  1,  0.0, 0.0, .98,  1.0,   4,   4,   4,   4 ),
      new StrokeDef("1", 0,  4,  4,  2,  0.0, 0.0, .98,  1.0,   4,   4,   4,   4 ),
      new StrokeDef("1", 3,  4,  4,  2,  0.0, 0.0, .98,  1.0,   4,   4,   4,   4 ),

      new StrokeDef("=E", 3,  4,  4,  0,  .98, 1.0, 0.0,  0.0,   4,   4,   4,   4 ),
      new StrokeDef("=E", 2,  4,  4,  0,  .98, 1.0, 0.0,  0.0,   4,   4,   4,   4 ),
      new StrokeDef("=E", 3,  4,  4,  1,  .98, 1.0, 0.0,  0.0,   4,   4,   4,   4 ),
      new StrokeDef("=E", 2,  4,  4,  1,  .98, 1.0, 0.0,  0.0,   4,   4,   4,   4 ),

      new StrokeDef("=W", 0,  4,  4,  3,  .98, 1.0, 0.0,  0.0,   4,   4,   4,   4 ),
      new StrokeDef("=W", 1,  4,  4,  3,  .98, 1.0, 0.0,  0.0,   4,   4,   4,   4 ),
      new StrokeDef("=W", 0,  4,  4,  2,  .98, 1.0, 0.0,  0.0,   4,   4,   4,   4 ),
      new StrokeDef("=W", 1,  4,  4,  2,  .98, 1.0, 0.0,  0.0,   4,   4,   4,   4 ),

      new StrokeDef("=NE", 2,  4,  4,  0, .99, 1.0, .99,  1.0,   4,   4,   4,   4 ),
      new StrokeDef("=NW", 1,  4,  4,  3, .99, 1.0, .99,  1.0,   4,   4,   4,   4 ),
      new StrokeDef("=SE", 3,  4,  4,  1, .99, 1.0, .99,  1.0,   4,   4,   4,   4 ),
      new StrokeDef("=SW", 0,  4,  4,  2, .99, 1.0, .99,  1.0,   4,   4,   4,   4 ),

      new StrokeDef("0",  3,  2,  1,  0,  1.5, 2.5, 1.5,  2.5,   0,   0,   0,   1 ),
      new StrokeDef("0",  3,  2,  0,  3,  1.5, 2.5, 1.5,  2.5,   0,   0,   0,   1 ),
      new StrokeDef("0",  0,  3,  1,  0,  1.5, 2.5, 1.5,  2.5,   0,   0,   0,   1 ),
      new StrokeDef("0",  0,  3,  0,  3,  1.5, 2.5, 1.5,  2.5,   0,   0,   0,   1 ),
      new StrokeDef("0",  0,  1,  3,  0,  1.5, 2.5, 1.5,  2.5,   1,   0,   1,   1 ),
      new StrokeDef("0",  0,  1,  2,  3,  1.5, 2.5, 1.5,  2.5,   1,   0,   1,   1 ),
      new StrokeDef("0",  3,  0,  3,  0,  1.5, 2.5, 1.5,  2.5,   1,   0,   1,   1 ),
      new StrokeDef("0",  3,  0,  2,  3,  1.5, 2.5, 1.5,  2.5,   1,   0,   1,   1 ),
      new StrokeDef("2",  3,  0,  2,  1,  2.0, 4.0, 0.9,  1.5,   1,   4,   1,   4 ),
      new StrokeDef("2",  3,  0,  2,  1,  2.0, 4.0, 0.9,  1.5,   1,   4,   1,   4 ),
      new StrokeDef("3",  3,  0,  1,  2,  2.0, 4.5, 0.9,  1.5,   1,   4,   0,   4 ),
      new StrokeDef("4",  3,  2,  2,  1,  0.9, 1.5, 0.9,  1.5,   4,   0,   1,   4 ),
      new StrokeDef("4",  0,  3,  2,  1,  0.9, 2.0, 0.9,  1.5,   0,   0,   1,   4 ),
      new StrokeDef("5",  0,  3,  1,  2,  2.0, 3.5, 0.9, 1.30,   0,   4,   0,   4 ),
      new StrokeDef("5",  3,  0,  1,  2,  2.0, 3.5, 0.9, 1.30,   0,   4,   0,   4 ),
      new StrokeDef("6",  0,  3,  4,  2,  1.5, 3.0, 1.31, 2.5,   0,   4,   0,   4 ),
      new StrokeDef("6",  3,  2,  4,  2,  1.5, 2.5, 1.31, 2.5,   0,   4,   0,   4 ),
      new StrokeDef("7",  3,  0,  0,  1,  0.9, 1.5, 0.9,  1.5,   1,   4,   4,   0 ),
      new StrokeDef("7",  3,  0,  1,  2,  0.9, 2.0, 0.9,  1.5,   1,   4,   4,   0 ),
      new StrokeDef("7",  3,  0,  3,  2,  0.9, 2.0, 0.9,  1.5,   1,   4,   4,   0 ),
      new StrokeDef("8",  0,  4,  4,  0,  2.5, 4.0, 1.5,  3.5,   4,   4,   4,   1 ),
      new StrokeDef("8",  0,  4,  4,  3,  2.5, 4.0, 1.5,  3.5,   4,   4,   4,   1 ),
      new StrokeDef("8",  3,  4,  4,  0,  2.5, 4.0, 1.5,  3.5,   4,   4,   4,   1 ),
      new StrokeDef("8",  3,  4,  4,  3,  2.5, 4.0, 1.5,  3.5,   4,   4,   4,   1 ),
      new StrokeDef("9",  0,  3,  0,  1,  1.5, 2.5, 1.3,  2.5,   0,   4,   4,   0 )
   };

   // graffiti stroke dictionary
   private static StrokeDef[] gsd =
   {
      new StrokeDef("=N", 1,  4,  4,  0,  0.0, 0.0, .98,  1.0,   4,   4,   4,   4 ),
      new StrokeDef("=N", 2,  4,  4,  0,  0.0, 0.0, .98,  1.0,   4,   4,   4,   4 ),
      new StrokeDef("=N", 1,  4,  4,  3,  0.0, 0.0, .98,  1.0,   4,   4,   4,   4 ),
      new StrokeDef("=N", 2,  4,  4,  3,  0.0, 0.0, .98,  1.0,   4,   4,   4,   4 ),
                                                           
      new StrokeDef("i", 0,  4,  4,  1,  0.0, 0.0, .98,  1.0,   4,   4,   4,   4 ),
      new StrokeDef("i", 3,  4,  4,  1,  0.0, 0.0, .98,  1.0,   4,   4,   4,   4 ),
      new StrokeDef("i", 0,  4,  4,  2,  0.0, 0.0, .98,  1.0,   4,   4,   4,   4 ),
      new StrokeDef("i", 3,  4,  4,  2,  0.0, 0.0, .98,  1.0,   4,   4,   4,   4 ),

      new StrokeDef("=E", 3,  4,  4,  0,  .98, 1.0, 0.0,  0.0,   4,   4,   4,   4 ),
      new StrokeDef("=E", 2,  4,  4,  0,  .98, 1.0, 0.0,  0.0,   4,   4,   4,   4 ),
      new StrokeDef("=E", 3,  4,  4,  1,  .98, 1.0, 0.0,  0.0,   4,   4,   4,   4 ),
      new StrokeDef("=E", 2,  4,  4,  1,  .98, 1.0, 0.0,  0.0,   4,   4,   4,   4 ),

      new StrokeDef("=W", 0,  4,  4,  3,  .98, 1.0, 0.0,  0.0,   4,   4,   4,   4 ),
      new StrokeDef("=W", 1,  4,  4,  3,  .98, 1.0, 0.0,  0.0,   4,   4,   4,   4 ),
      new StrokeDef("=W", 0,  4,  4,  2,  .98, 1.0, 0.0,  0.0,   4,   4,   4,   4 ),
      new StrokeDef("=W", 1,  4,  4,  2,  .98, 1.0, 0.0,  0.0,   4,   4,   4,   4 ),

      new StrokeDef("=NE", 2,  4,  4,  0, .99, 1.0, .99,  1.0,   4,   4,   4,   4 ),
      new StrokeDef("=NW", 1,  4,  4,  3, .99, 1.0, .99,  1.0,   4,   4,   4,   4 ),
      new StrokeDef("=SE", 3,  4,  4,  1, .99, 1.0, .99,  1.0,   4,   4,   4,   4 ),
      new StrokeDef("=SW", 0,  4,  4,  2, .99, 1.0, .99,  1.0,   4,   4,   4,   4 ),

      new StrokeDef("a",  2,  3,  0,  1,  0.9, 1.2, 1.5,  2.0,   4,   1,   4,   0 ),
      new StrokeDef("b",  3,  2,  1,  2,  2.3, 4.0, 2.5,  3.5,   4,   0,   0,   4 ),
      new StrokeDef("b",  2,  3,  1,  2,  2.3, 4.0, 1.5,  2.5,   4,   1,   0,   4 ),
      new StrokeDef("c",  0,  3,  2,  1,  1.5, 2.0, 0.9,  2.0,   0,   4,   1,   4 ),
      new StrokeDef("d",  3,  2,  1,  2,  1.5, 2.3, 2.0,  3.0,   4,   0,   0,   4 ),
      new StrokeDef("d",  2,  3,  1,  2,  1.5, 2.3, 1.5,  2.5,   4,   1,   0,   4 ),
      new StrokeDef("e",  0,  3,  2,  1,  2.7, 4.0, 0.9,  2.0,   0,   4,   1,   4 ),
      new StrokeDef("f",  0,  3,  3,  2,  0.9, 1.3, 0.9, 1.25,   0,   4,   4,   0 ),
      new StrokeDef("g",  0,  3,  4,  2,  1.5, 3.0, 1.3,  2.5,   0,   4,   0,   4),
      new StrokeDef("g",  0,  3,  2,  1,  1.8, 2.7, 1.2,  2.2,   0,   4,   1,   4 ),
      new StrokeDef("h",  3,  2,  0,  1,  0.9, 1.5, 1.2,  2.5,   4,   0,   4,   0 ),
      new StrokeDef("h",  3,  2,  2,  1,  0.9, 1.5, 1.2,  2.5,   4,   0,   4,   0 ),
      new StrokeDef("h",  3,  2,  3,  1,  0.9, 1.5, 0.9,  2.5,   4,   0,   4,   0 ),
      new StrokeDef("j",  0,  1,  1,  2,  0.9, 1.4, 0.9, 1.25,   4,   0,   0,   4 ),
      new StrokeDef("k",  0,  4,  4,  1,  1.5, 2.5, 1.5,  2.5,   0,   0,   1,   0 ),
      new StrokeDef("l",  3,  2,  2,  1,  0.9, 1.3, 0.9, 1.25,   4,   0,   1,   4 ),
      new StrokeDef("m",  2,  3,  0,  1,  0.9, 1.5, 2.0,  4.0,   4,   1,   4,   0 ),
      new StrokeDef("m",  3,  2,  0,  1,  0.9, 1.5, 3.0,  4.5,   4,   0,   4,   0 ),
      new StrokeDef("n",  2,  3,  1,  0,  0.9, 1.5, 2.3,  4.0,   4,   1,   4,   1 ),
      new StrokeDef("o",  3,  2,  1,  0,  1.5, 2.5, 1.5,  2.5,   0,   0,   0,   1 ),
      new StrokeDef("o",  3,  2,  0,  3,  1.5, 2.5, 1.5,  2.5,   0,   0,   0,   1 ),
      new StrokeDef("o",  0,  3,  1,  0,  1.5, 2.5, 1.5,  2.5,   0,   0,   0,   1 ),
      new StrokeDef("o",  0,  3,  0,  3,  1.5, 2.5, 1.5,  2.5,   0,   0,   0,   1 ),
      new StrokeDef("o",  0,  1,  3,  0,  1.5, 2.5, 1.5,  2.5,   1,   0,   1,   1 ),
      new StrokeDef("o",  0,  1,  2,  3,  1.5, 2.5, 1.5,  2.5,   1,   0,   1,   1 ),
      new StrokeDef("o",  3,  0,  3,  0,  1.5, 2.5, 1.5,  2.5,   1,   0,   1,   1 ),
      new StrokeDef("o",  3,  0,  2,  3,  1.5, 2.5, 1.5,  2.5,   1,   0,   1,   1 ),
      new StrokeDef("p",  3,  2,  2,  3,  1.6, 3.0, 2.0,  3.5,   4,   0,   0,   4 ),
      new StrokeDef("p",  3,  2,  0,  3,  1.6, 3.0, 2.0,  3.5,   4,   0,   0,   4 ),
      new StrokeDef("p",  3,  2,  1,  3,  1.6, 3.0, 2.0,  3.5,   4,   0,   0,   4 ),
      new StrokeDef("p",  2,  3,  0,  3,  1.6, 3.0, 1.2,  3.5,   4,   1,   0,   4 ),
      new StrokeDef("q",  0,  3,  1,  0,  1.5, 2.5, 1.8,  3.0,   0,   0,   1,   4 ),
      new StrokeDef("q",  0,  3,  3,  0,  1.5, 2.5, 1.8,  3.0,   0,   0,   1,   4 ),
      new StrokeDef("q",  3,  2,  1,  0,  1.5, 2.5, 1.8,  3.0,   0,   0,   1,   4 ),
      new StrokeDef("q",  3,  2,  3,  0,  1.5, 2.5, 1.8,  3.0,   0,   0,   1,   4 ),
      new StrokeDef("r",  3,  2,  4,  1,  2.0, 3.0, 2.0,  3.0,   4,   0,   1,   0 ),
      new StrokeDef("r",  2,  3,  4,  1,  2.0, 3.0, 1.6,  3.0,   4,   1,   1,   0 ),
      new StrokeDef("s",  0,  3,  1,  2,  2.0, 3.5, 0.9,  2.0,   0,   4,   0,   4 ),
      new StrokeDef("t",  3,  0,  0,  1,  0.9, 1.2, 0.9, 1.25,   1,   4,   4,   0 ),
      new StrokeDef("u",  3,  2,  1,  0,  0.9, 2.5, 0.9,  2.0,   4,   0,   4,   1 ),
      new StrokeDef("v",  3,  4,  4,  0,  0.9, 1.2, 1.5,  2.0,   1,   0,   1,   0 ),
      new StrokeDef("v",  0,  1,  2,  3,  0.9, 1.4, 1.5,  2.0,   4,   0,   4,   1 ),
      new StrokeDef("w",  3,  2,  1,  0,  0.9, 1.5, 2.0,  4.0,   4,   0,   4,   1 ),
      new StrokeDef("x",  3,  4,  4,  2,  1.5, 2.5, 1.5,  3.5,   1,   0,   0,   0 ),
      new StrokeDef("y",  3,  4,  4,  2,  0.9, 2.0, 1.5,  2.5,   1,   0,   0,   4 ),
      new StrokeDef("y",  3,  4,  4,  0,  1.5, 2.8, 1.5,  2.9,   1,   0,   1,   1 ),
      new StrokeDef("y",  3,  4,  4,  1,  1.4, 3.0, 1.5,  2.5,   1,   0,   1,   4 ),
      new StrokeDef("z",  3,  0,  2,  1,  2.2, 3.5, 0.9,  2.0,   1,   4,   1,   4 )
   };

   // unistrokes stroke dictionary
   private static StrokeDef[] usd =
   {
      new StrokeDef("a", 1,  4,  4,  0,  0.0, 0.0, .98,  1.0,   4,   4,   4,   4 ),
      new StrokeDef("a", 2,  4,  4,  0,  0.0, 0.0, .98,  1.0,   4,   4,   4,   4 ),
      new StrokeDef("a", 1,  4,  4,  3,  0.0, 0.0, .98,  1.0,   4,   4,   4,   4 ),
      new StrokeDef("a", 2,  4,  4,  3,  0.0, 0.0, .98,  1.0,   4,   4,   4,   4 ),
                                                           
      new StrokeDef("i", 0,  4,  4,  1,  0.0, 0.0, .98,  1.0,   4,   4,   4,   4 ),
      new StrokeDef("i", 3,  4,  4,  1,  0.0, 0.0, .98,  1.0,   4,   4,   4,   4 ),
      new StrokeDef("i", 0,  4,  4,  2,  0.0, 0.0, .98,  1.0,   4,   4,   4,   4 ),
      new StrokeDef("i", 3,  4,  4,  2,  0.0, 0.0, .98,  1.0,   4,   4,   4,   4 ),

      new StrokeDef("t", 3,  4,  4,  0,  .98, 1.0, 0.0,  0.0,   4,   4,   4,   4 ),
      new StrokeDef("t", 2,  4,  4,  0,  .98, 1.0, 0.0,  0.0,   4,   4,   4,   4 ),
      new StrokeDef("t", 3,  4,  4,  1,  .98, 1.0, 0.0,  0.0,   4,   4,   4,   4 ),
      new StrokeDef("t", 2,  4,  4,  1,  .98, 1.0, 0.0,  0.0,   4,   4,   4,   4 ),

      new StrokeDef("e", 0,  4,  4,  3,  .98, 1.0, 0.0,  0.0,   4,   4,   4,   4 ),
      new StrokeDef("e", 1,  4,  4,  3,  .98, 1.0, 0.0,  0.0,   4,   4,   4,   4 ),
      new StrokeDef("e", 0,  4,  4,  2,  .98, 1.0, 0.0,  0.0,   4,   4,   4,   4 ),
      new StrokeDef("e", 1,  4,  4,  2,  .98, 1.0, 0.0,  0.0,   4,   4,   4,   4 ),

      new StrokeDef("k", 2,  4,  4,  0, .99, 1.0, .99,  1.0,   4,   4,   4,   4 ),
      new StrokeDef("=NW", 1,  4,  4,  3, .99, 1.0, .99,  1.0,   4,   4,   4,   4 ),
      new StrokeDef("r", 3,  4,  4,  1, .99, 1.0, .99,  1.0,   4,   4,   4,   4 ),
      new StrokeDef("y", 0,  4,  4,  2, .99, 1.0, .99,  1.0,   4,   4,   4,   4 ),

      new StrokeDef("b", 3, 0, 1, 2, 1.5, 2.5, 0.9, 1.5, 1, 0, 0, 0),
      new StrokeDef("c", 1, 2, 3, 0, 1.5, 2.5, 0.9, 1.5, 0, 1, 1, 1),
      new StrokeDef("d", 0, 3, 2, 1, 1.5, 2.5, 0.9, 1.5, 0, 0, 1, 0),
      new StrokeDef("f", 0, 3, 3, 2, 0.9, 1.5, 0.9, 1.5, 0, 4, 4, 0),
      new StrokeDef("g", 2, 1, 1, 0, 0.9, 1.5, 0.9, 1.5, 1, 4, 4, 1),
      new StrokeDef("h", 3, 0, 0, 1, 0.9, 1.5, 0.9, 1.5, 1, 4, 4, 0),
      new StrokeDef("j", 0, 1, 1, 2, 0.9, 1.5, 0.9, 1.5, 4, 0, 0, 4),
      new StrokeDef("l", 3, 2, 2, 1, 0.9, 1.5, 0.9, 1.5, 4, 0, 1, 4),
      new StrokeDef("m", 1, 0, 3, 2, 0.9, 1.5, 1.5, 2.5, 0, 1, 0, 0),
      new StrokeDef("n", 2, 3, 0, 1, 0.9, 1.5, 1.5, 2.5, 1, 1, 1, 0),
      new StrokeDef("o", 0, 4, 4, 3, 1.5, 2.5, 1.5, 2.5, 0, 0, 0, 1),
      new StrokeDef("p", 3, 4, 4, 2, 1.5, 2.5, 1.5, 2.5, 1, 0, 0, 0),
      new StrokeDef("q", 0, 4, 4, 1, 1.5, 2.5, 1.5, 2.5, 0, 0, 1, 0),
      new StrokeDef("r", 3, 4, 4, 1, 0.9, 1.5, 0.9, 1.5, 1, 0, 1, 0),
      new StrokeDef("s", 0, 3, 1, 2, 2.0, 3.0, 0.9, 1.5, 0, 4, 0, 4),
      new StrokeDef("u", 0, 1, 2, 3, 0.9, 1.5, 1.5, 2.5, 0, 0, 0, 1),
      new StrokeDef("v", 3, 2, 1, 0, 0.9, 1.5, 1.5, 2.0, 1, 0, 1, 1),
      new StrokeDef("w", 3, 2, 0, 1, 0.9, 1.5, 2.0, 3.0, 4, 0, 4, 0),
      new StrokeDef("x", 3, 4, 4, 0, 1.5, 2.5, 1.5, 2.5, 1, 0, 1, 1),
      new StrokeDef("y", 2, 4, 4, 0, 0.9, 1.5, 0.9, 1.5, 1, 1, 1, 1),
      new StrokeDef("z", 3, 0, 2, 1, 2.0, 3.0, 0.9, 1.5, 1, 4, 1, 4),
      new StrokeDef("=CR", 2, 1, 0, 3, 1.5, 2.5, 0.9, 1.5, 1, 1, 0, 1)
   };

   /** Provides access to the currently active stroke dictionary.<p>
   *
   * A variety of debugging and advanced programming
   * services are available through this public variable.
   *
   * Given a <code>Unistroke</code> object <code>u</code>, the
   * number of entries in the currently active dictionary is
   *
   * <pre>
   *     u.activeDictionary.length
   * </pre>
   *
   * Each entry in the currently active dictionary may be
   * retrieved.  For example
   *
   * <pre>
   *     for (int i = 0; i < u.activeDictionary.length; ++i)
   *        System.out.println(u.activeDictionary[i]);
   * </pre>
   *
   * outputs the entire dictionary to the console.<p>
   *
   * Each row in the dictionary is returned as a string containing
   * thirteen comma-delimited values.  For example, the entry
   * for the letter "a" in the built-in graffiti dictionary appears
   * as follows:<p>
   *
   * <pre>
   *     a, 2, 3, 0, 1, 0.9, 1.2, 1.5, 2.0, 4, 1, 4, 0
   * </pre>
   *
   * where
   *
   * <pre>
   *     symbol = a
   *     quadf  = 2
   *     quads  = 3
   *     quadsl = 0
   *     quadl  = 1
   *     kxmin  = 0.9
   *     kxmax  = 1.2
   *     kymin  = 1.5
   *     kymax  = 2.0
   *     startx = 4
   *     starty = 1
   *     stopx  = 4
   *     stopy  = 0
   * </pre>
   *
   * See the description for the <code>loadDictionary()</code> method for
   * further discussion on each entry in the dictionary.
   *
   * @see #loadDictionary
   */
   public StrokeDef[] activeDictionary;

   private static StrokeDef[] custom1;
   private static StrokeDef[] custom2;
   private static StrokeDef[] custom3;
   private static StrokeDef[] custom4;
   private static StrokeDef[] custom5;
   private static final int POS = 1;
   private static final int NEG = 0;

   private String undefinedStroke;
   private boolean flipX = false;
   private boolean flipY = false;
   private int tapThreshhold;
   private double aspectRatio;
   private final int DC = 4; // don't care
   private int quadf  = 0;
   private int quads  = 0;
   private int quadsl = 0;
   private int quadl  = 0;
   private double kx = 0.0;
   private double ky = 0.0;
   private int startx = 0;
   private int starty = 0;
   private int stopx = 0;
   private int stopy = 0;

   /** Construct a Unistroke object.<p>
   *
   * Once a Unistroke object is declared, character recognition
   * may proceed immediately via the <code>recognize()</code>
   * method.
   *
   * The default dictionary is the graffiti dictionary.<p>
   */
   Unistroke()
   {
      tapThreshhold = TAP_THRESHHOLD;
      aspectRatio = ASPECT_RATIO;
      undefinedStroke = UNDEFINED_STROKE;

      setDictionary(GRAFFITI); // set default dictionary to graffiti
   }

   /** Change the threshhold setting for a tap.<p>
   *
   * The definition of a stylus "tap" is any stroke with less than a certain
   * threshhold of samples.  The default threshhold is 5.<p>
   *
   * The <code>recognize()</code> method returns "=TAP" for any stroke
   * meeting this criterion.<p>
   *
   * @param n an integer representing the number of samples below which
   * a stroke is considered a tap.
   */
   public void setTapThreshhold(int n)
   {
      tapThreshhold = n;
   }

   /** Change the return string for an undefined stroke.<p>
   *
   * By default, the recognizer returns the string "<code>#</code>"
   * (hash symbol) for unrecognized strokes.<p>
   *
   * @param s the new return string for unrecognized strokes
   */
   public void setUndefined(String s)
   {
      undefinedStroke = new String(s);
   }

   /** Change the aspect ratio for horizontal or vertical strokes.
   *
   * The default aspect ratio is 0.2.<p>
   *
   * @param d a <code>double</code> representing the new aspect ratio.<p>
   * </dl><p>
   *
   * <hr><p>
   * Discussion:<p>
   *
   * Horizontal or vertical strokes pose a special problem for the
   * recognizer because the stroke shape is grossly distorted when the
   * sample points are normalized.  To accommodate this, a special
   * test is performed on the unnormalized sample points to determine
   * if a stroke is horizontal or vertical.<p>
   *
   * A stroke is recognized as horizontal or vertical if the aspect
   * ratio &mdash; the thickness-to-length ratio &mdash;
   * of the unnormalized sample points is less than a certain
   * threshhold.  The default is 0.2.<p>
   *
   * A stroke meeting the criteron above is explicitly assigned
   * the following values for its cumulative x distance
   * and cumulative y distance:<p>
   *
   * <pre>
   *     stroke   kx   ky
   *     ------  ---  ---
   *     NORTH   1.0  0.0
   *     SOUTH   1.0  0.0
   *     EAST    0.0  1.0
   *     WEST    0.0  1.0
   * </pre>
   */
   public void setAspectRatio(double d)
   {
      aspectRatio = d;
   }

   /** Flip the orientation of the y coordinates.<p>
   *
   * The sample points passed to the <code>recognize()</code>
   * method are assumed to be consistent with Java's
   * AWT coordinate system: namely, x coordinates increase moving
   * to the right across the display, and y coordinates increase moving
   * down the display.  The <code>flipY()</code> method
   * can be used to reverse
   * the orientation of the y coordinates, if necessary.<p>
   *
   * This method needs to be called once only, after instantiating
   * the <code>Unistroke</code> object.  If the method is called a
   * a second time, the original orientation is restored.
   */
   public void flipY()
   {
      flipY = !flipY;
   }

   /** Flip the orientation of the x coordinates.
   *
   * See the <code>flipY()</code> method for discussion.
   */
   public void flipX()
   {
      flipX = !flipX;
   }

   /** Set or change the active dictionary. For example,<p>
   *
   * <pre>
   *     setDictionary(Unistroke.DIGITS);
   * </pre>
   *
   * changes the currently active dictionary to the digits
   * dictionary.<p>
   *
   * @param d an integer representing a dictionary.<p>
   * The following
   * dictionaries are defined:<p>
   *
   * <pre>
   * Unistroke.GRAFFITI   - built-in graffiti dictionary (default)
   * Unistroke.UNISTROKES - built-in unistrokes dictionary
   * Unistroke.DIGITS     - build-in digits dictionary
   * Unistroke.CUSTOM1    - user-provided custom dictionary #1
   * Unistroke.CUSTOM2    - user-provided custom dictionary #2
   * Unistroke.CUSTOM3    - user-provided custom dictionary #3 
   * Unistroke.CUSTOM4    - user-provided custom dictionary #4
   * Unistroke.CUSTOM5    - user-provided custom dictionary #5
   * </pre>
   */
   public void setDictionary(int d)
   {
      if (d == GRAFFITI)
         activeDictionary = gsd;      // graffiti stroke dictionary
      else if (d == UNISTROKES)
         activeDictionary = usd;      // unistrokes stroke dictionary
      else if (d == DIGITS)
         activeDictionary = dsd;      // digits stroke dictionary
      else if (d == CUSTOM1)
         activeDictionary = custom1;  // custom1 stroke dictionary
      else if (d == CUSTOM2)
         activeDictionary = custom2;  // custom2 stroke dictionary
      else if (d == CUSTOM3)
         activeDictionary = custom3;  // custom3 stroke dictionary
      else if (d == CUSTOM4)
         activeDictionary = custom4;  // custom4 stroke dictionary
      else if (d == CUSTOM5)
         activeDictionary = custom5;  // custom5 stroke dictionary
   }


   /***** Get stroke characteristics *****/

   //private int getSTRKquadf()  { return quadf;  }
   //private int getSTRKquads()  { return quads;  }
   //private int getSTRKquadsl() { return quadsl; }
   //private int getSTRKquadl()  { return quadl;  }
   //private double getSTRKkx()  { return (int)(kx * 100) / 100.0 ; }
   //private double getSTRKky()  { return (int)(ky * 100) / 100.0 ; }
   //private int getSTRKstartx() { return startx; }
   //private int getSTRKstarty() { return starty; }
   //private int getSTRKstopx()  { return stopx;  }
   //private int getSTRKstopy()  { return stopy;  }

   // flip the orientation of the sample points, as per flipX & flipY
   private void flip(int[] x, int[] y, int n)
   {
      for (int i = 0; i < n; ++i)
      {
         if (flipX)
            x[i] = Integer.MAX_VALUE - x[i];
         if (flipY)
            y[i] = Integer.MAX_VALUE - y[i];
      }
   }

   /** Perform unistroke character recognition.  This is the basic
   * method to convert a series of x-y sample points to a character.
   * The returned string is one of the following:<p>
   *
   * <ol>
   * <li>a string containing the entry in the
   * dictionary corresponding to the stroke, if recognition was
   * successful,
   * <li>the string "<code>#</code>" (hash symbol),
   * if a match for the stroke was not found, or
   * <li>the string "<code>=TAP</code>" if the stroke meets the criterion for
   * a "tap" (i.e., it contains less than a certain threshhold of samples).
   * </ol>
   *
   * @param x an integer array of x sample points.
   * @param y an integer array of y sample points.
   * @return a string representation of the recognized unistroke character,<p>
   */
   public String recognize(int[] x, int[] y)
   {
      // make copies of arrays, so original data are intact
      int[] xx = new int[x.length];
      int[] yy = new int[x.length];
      for (int i = 0; i < x.length; ++i)
      {
         xx[i] = x[i];
         yy[i] = y[i];
      }

      // flip orientation of sample points, if necessary
      flip(xx, yy, xx.length);

      // do the recognition and return result
      return toCharacter(xx, yy, xx.length);
   }

   /** Perform unistroke character recognition (3-arg version).
   * @param x an integer array of x sample points.
   * @param y an integer array of y sample points.
   * @param length an integer representing the number of elements
   * in the arrays to process
   * @return a string representation of the recognized unistroke character,<p>
   */
   public String recognize(int[] x, int[] y, int length)
   {
      // make copies of arrays, so original data are intact
      int[] xx = new int[length];
      int[] yy = new int[length];
      for (int i = 0; i < length; ++i)
      {
         xx[i] = x[i];
         yy[i] = y[i];
      }

      // flip orientation of sample points, if necessary
      flip(xx, yy, length);

      // do the recognition and return result
      return toCharacter(xx, yy, length);
   }

   /** Perform unistroke character recognition (Point class version).
   * @param p an array of Point objects.
   * @param length an integer representing the number of elements
   * in the Point array to process
   * @return a string representation of the recognized unistroke character,<p>
   */
   public String recognize(Point p[], int length)
   {
      // make arrays
      int[] xx = new int[length];
      int[] yy = new int[length];
      for (int i = 0; i < length; ++i)
      {
         xx[i] = (int)p[i].getX();
         yy[i] = (int)p[i].getY();
      }

      // flip orientation of sample points, if necessary
      flip(xx, yy, length);

      // do the recognition and return result
      return toCharacter(xx, yy, length);
   }

   /** Calculate and return the features of a unistroke (3-arg version) */
   public String getFeatures(int[] x, int[] y, int length)
   {
      // perform dummy recognition (mostly to compute the features)
      String s = recognize(x, y, length);

      if (s.equals("=TAP"))
         return s;
      else
         return quadf + ", " + quads + ", " + quadsl + ", " + quadl + ", " +
             String.format("%.3f", kx) + ", " +         
             String.format("%.3f", ky) + ", " +
             startx + ", " + starty + ", " + stopx + ", " + stopy;
   }

   /** Calculate and return the features of a unistroke.
   * The returned string is one of the following:<p>
   *
   * <ol>
   * <li>a string containing a set of ten comma-delimited
   * features for the passed unistroke, or
   * <li>the string "<code>=TAP</code>" for a stylus "tap".
   * </ol><p>
   *
   * For example, the following
   * could be the returned string for a unistroke resembling a
   * graffiti "a":<p>
   *
   * <pre>
   *     2, 3, 0, 1, 1.010, 1.857, 1, 1, 1, 0
   * </pre>
   *
   * The ten values above represent the following unistroke features:<p>
   *
   * <pre>
   *     quadf  = 2
   *     quads  = 3
   *     quadsl = 0
   *     quadl  = 1
   *     kx     = 1.010
   *     ky     = 1.855
   *     startx = 1
   *     starty = 1
   *     stopx  = 1
   *     stopy  = 0
   * </pre>
   *
   * @param x an integer array of x sample points.
   * @param y an integer array of y sample points.
   * @return a string containing the features of the passed unistroke,
   * or "<code>=TAP</code>" for a unistroke representing a stylus tap.
   *
   */
   public String getFeatures(int[] x, int[] y)
   {
      // perform dummy recognition (mostly to compute the features)
      String s = recognize(x, y);

      if (s.equals("=TAP"))
         return s;
      else
         return quadf + ", " + quads + ", " + quadsl + ", " + quadl + ", " +
             String.format("%.5f", kx) + ", " +
             String.format("%.5f", ky) + ", " +
             startx + ", " + starty + ", " + stopx + ", " + stopy;
   }

   //========================================================
   // All the work is done here!
   //========================================================
   private String toCharacter(int[] x, int[] y, int n)
   {
      StrokeDef[] d = activeDictionary; // just make a copy for convenience

      double xl = Double.MAX_VALUE;
      double xu = Double.MIN_VALUE;
      double yl = Double.MAX_VALUE;
      double yu = Double.MIN_VALUE;

      double[] nx = new double[n];
      double[] ny = new double[n];
      kx = 0.0;
      ky = 0.0;
      startx = 0;
      starty = 0;
      stopx = 0;
      stopy = 0;
      double tstartx = 0.0;
      double tstarty = 0.0;
      double tstopx = 0.0;
      double tstopy = 0.0;

      // if less than "tapThreshhold" points, it's a "tap"
      if (n < tapThreshhold)
         return "=TAP";

      //--------------------------
      // Calculate Stroke Features
      //--------------------------

      // Find mins and maxes for sample points on x and y axes 
      for (int j = 0; j < n; ++j)
      {
         if (x[j] < xl) xl = x[j];  // x lower 
         if (x[j] > xu) xu = x[j];  // x upper 
         if (y[j] < yl) yl = y[j];  // y lower 
         if (y[j] > yu) yu = y[j];  // y upper 
      }

      // Normalize points to fit in a "unit" bounding box 
      for (int j = 0; j < n; ++j)
      {
         if ((xu - xl) != 0.0)
            nx[j] = x[j] / (xu - xl) - xl / (xu - xl);
         else
            nx[j] = 0.5;

         if ((yu - yl) != 0.0)
            ny[j] = y[j] / (yu - yl) - yl / (yu - yl);
         else
            ny[j] = 0.5;
      }

      //---------------------------------------------------------
      // Calculate cumulative length of stroke along x and y axes
      //----------------------------------------------------------
      for (int j = 1; j < n; ++j)
      {
         kx += Math.abs(nx[j] - nx[j - 1]);
         ky += Math.abs(ny[j] - ny[j - 1]);
      }

      //-----------------------------------------------
      // Determine 1st, 2nd, 2nd last, & last quadrants
      //-----------------------------------------------
      // where...           -------
      // 0 = upper right   | 3 | 0 |
      // 1 = lower right   |-------|
      // 2 = lower left    | 2 | 1 |
      // 3 = upper left     -------
      //
      quadf = findQuad(nx[0], ny[0]);
      quads = quadf; // default
      quadl  = findQuad(nx[n - 1], ny[n - 1]);
      quadsl = quadl; // default
      for (int j = 0; j < n; ++j)
         if (findQuad(nx[j], ny[j]) == quadf)
            continue;
         else
         {
            quads = findQuad(nx[j], ny[j]);
            break;
         }
      for (int j = n - 1; j >= 0; --j)
         if (findQuad(nx[j], ny[j]) == quadl)
            continue;
         else {
            quadsl = findQuad(nx[j], ny[j]);
            break;
         }

      //-------------------------------------------------------
      // Determine starting and terminating direction of stroke
      //-------------------------------------------------------
      // Note: based on 1st and last 25% of sample points
      // E.g., if startx > 0.0, movement is to the right
      //       if starty > 0.0, movement is up
      for(int j = 0; j < (int)(0.25 * n); ++j)
      {
         tstartx += nx[j + 1] - nx[j];
         tstarty += ny[j + 1] - ny[j];
         tstopx  += nx[n - j - 1] - nx[n - j - 2];
         tstopy  += ny[n - j - 1] - ny[n - j - 2];
      }
      if (tstartx > 0.0) startx = POS; // to the right
      if (tstartx < 0.0) startx = NEG; // to the left
      if (tstarty < 0.0) starty = POS; // down
      if (tstarty > 0.0) starty = NEG; // up
      if (tstopx  > 0.0) stopx  = POS;
      if (tstopx  < 0.0) stopx  = NEG;
      if (tstopy  < 0.0) stopy  = POS;
      if (tstopy  > 0.0) stopy  = NEG;

      //-----------------------------------------
      // Check for vertical or horizontal strokes
      //-----------------------------------------
      // reassign kx and ky, if necessary
      // "north"
      if ((xu - xl) < aspectRatio * (yu - yl) && ny[0] > ny[n - 1])
      {
         kx = 0.0;
         ky = 1.0;
      }

      // "east"
      if ((yu - yl) < aspectRatio * (xu - xl) && nx[0] < nx[n - 1])
      {
         kx = 1.0;
         ky = 0.0;
      }

      // "west" 
      if ((yu - yl) < aspectRatio * (xu - xl) && nx[0] > nx[n - 1])
      {
         kx = 1.0;
         ky = 0.0;
      }

      // "south" (probably "i" or "1") 
      if ((xu - xl) < aspectRatio * (yu - yl) && ny[0] < ny[n - 1]) 
      {
         kx = 0.0;
         ky = 1.0;
      }

      //-----------------------------------
      // Look for a match in the dictionary
      //-----------------------------------
		matchString = new Vector<String>();
		//int p = 0;
      for (int j = 0; j < d.length; j++)
		{
         if (  (quadf  == d[j].getDEFquadf()  || d[j].getDEFquadf()  == DC) &&
               (quads  == d[j].getDEFquads()  || d[j].getDEFquads()  == DC) &&
               (quadsl == d[j].getDEFquadsl() || d[j].getDEFquadsl() == DC) &&
               (quadl  == d[j].getDEFquadl()  || d[j].getDEFquadl()  == DC) &&
               kx >= d[j].getDEFkxmin() &&
               kx <= d[j].getDEFkxmax() &&
               ky >= d[j].getDEFkymin() &&
               ky <= d[j].getDEFkymax() &&
               (startx == d[j].getDEFstartX() || d[j].getDEFstartX() == DC) &&
               (starty == d[j].getDEFstartY() || d[j].getDEFstartY() == DC) &&
               (stopx  == d[j].getDEFstopX()  || d[j].getDEFstopX()  == DC) &&
               (stopy  == d[j].getDEFstopY()  || d[j].getDEFstopY()  == DC) )
			{
				matchString.add(d[j].getDEFsymbol());
            //return d[j].getDEFsymbol(); // done! return the recognized character
			}
		}
		if (matchString.size() > 0)
			return matchString.elementAt(0);
		else
			return undefinedStroke; // No match: return string for unrecognized stroke
   }

	public static Vector<String> matchString;

   private int findQuad(double x, double y)
   {
      if (x >= 0.5 && y <= 0.5) return 0; // upper right 
      if (x >= 0.5 && y >  0.5) return 1; // lower right 
      if (x <  0.5 && y >  0.5) return 2; // lower left  
      if (x <  0.5 && y <= 0.5) return 3; // upper left  
      return 0;
   }

   /** Test the <code>Unistroke</code> class.
   */
   public static void main(String[] args) throws IOException
   {
      System.out.println("Size of graffiti dictionary: " + gsd.length);
      System.out.println("Size of unistrokes dictionary: " + usd.length);
      System.out.println("Size of digit dictionary: " + dsd.length);

      System.out.println("\nConstructor a Unistroke object...");
      Unistroke u = new Unistroke();

      System.out.println("\nSize of currently active dictionary: " +
         u.activeDictionary.length);

      System.out.println("\n***** Example #1 *****");
      // unistroke (looks like the letter "oh" or the number "zero"
      int[] x1 = { 6, 7, 8, 9, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 2, 3, 4, 5 };
      int[] y1 = {10, 9, 8, 7,  6, 5, 4, 3, 2, 2, 3, 4, 5, 6, 7, 8, 9, 10};

      System.out.println("Sample points... (the letter \"oh\" in graffiti)");
      for (int i = 0; i < x1.length; ++i)
         System.out.print("{" + x1[i] + "," + y1[i] + "} ");
      System.out.println();

      System.out.println("Call the recognize() method...");
      System.out.println("Recognized character: " + u.recognize(x1, y1));

      System.out.println("Stroke features: " +
         u.getFeatures(x1, y1, x1.length));

      System.out.println("Oops! Need to flip the Y coordinates.");

      System.out.println("Call the flipY() method...");
      u.flipY(); // needed for java graphics coordinate system

      System.out.println("Call the recognize() method (again)...");
      System.out.println("Recognized character: " + u.recognize(x1, y1));

      System.out.println("Stroke features: " + u.getFeatures(x1, y1, x1.length));

      System.out.println("Change to digits dictionary");
      u.setDictionary(DIGITS);

      System.out.println("Recognized character: " + u.recognize(x1, y1));

      System.out.println("Change back to graffiti dictionary");
      u.setDictionary(GRAFFITI);
      System.out.println("Recognized character: " + u.recognize(x1, y1));

      System.out.println("Change to unistrokes dictionary");
      u.setDictionary(UNISTROKES);

      System.out.println("Recognized character: " + u.recognize(x1, y1));

 
      System.out.println("\n***** Example #2 *****");
      // unistroke (a stroke to the left)
      int[] x2 = {20, 18, 16, 14, 12, 10, 9, 8, 7, 6, 5, 4, 3, 3, 2, 2, 1, 1};
      int[] y2 = { 2,  2,  2,  3,  2,  2, 3, 2, 3, 2, 3, 2, 3, 2, 3, 2, 2, 2};

      System.out.println("Sample points... (stroke to the left)");
      for (int i = 0; i < x2.length; ++i)
         System.out.print("{" + x2[i] + "," + y2[i] + "} ");
      System.out.println();

      System.out.println("First let's try graffiti dictionary");
      u.setDictionary(GRAFFITI);

      System.out.println("Call the recognize() method...");
      System.out.println("Recognized character: " + u.recognize(x2, y2));

      System.out.println("Stroke features: " +
         u.getFeatures(x2, y2, x2.length));

      System.out.println("Change to digits dictionary");
      u.setDictionary(DIGITS);

      System.out.println("Recognized character: " + u.recognize(x2, y2));

      System.out.println("Change to unistrokes dictionary");
      u.setDictionary(UNISTROKES);

      System.out.println("Recognized character: " + u.recognize(x2, y2));

      System.out.println("\n***** Example #3 *****");
      // unistroke (a stroke to the left, but only 4 sample points)
      int[] x3 = {40, 15, 10, 15};
      int[] y3 = { 2,  2,  3,  2};

      System.out.println("Sample points... \"tap\" = < 5 sample points)");
      for (int i = 0; i < x3.length; ++i)
         System.out.print("{" + x3[i] + "," + y3[i] + "} ");
      System.out.println();

      System.out.println("First let's try graffiti dictionary");
      u.setDictionary(GRAFFITI);

      System.out.println("Call the recognize() method...");
      System.out.println("Recognized character: " + u.recognize(x3, y3));

      System.out.println("Stroke features: " +
         u.getFeatures(x3, y3, x3.length));

      System.out.println("Change to digits dictionary");
      u.setDictionary(DIGITS);

      System.out.println("Recognized character: " + u.recognize(x3, y3));

      System.out.println("Change to unistrokes dictionary");
      u.setDictionary(UNISTROKES);

      System.out.println("Recognized character: " + u.recognize(x3, y3));

      System.out.println("Change tap \"threshhold\" to 3 ...");
      u.setTapThreshhold(3);
      System.out.println("Recognized character: " + u.recognize(x3, y3));

      System.out.println("Change straight-line \"aspect ratio\" to 0.1 ...");
      u.setAspectRatio(0.1);     
      System.out.println("Recognized character: " + u.recognize(x3, y3));

      System.out.println("Change return string for unrecognized stroke...");
      u.setUndefined("????");
      System.out.println("Recognized character: " + u.recognize(x3, y3));

      System.out.println("Restore default settings ...");
      u.setTapThreshhold(5);
      u.setAspectRatio(0.2);
      u.setUndefined("#");

      System.out.println("\n***** Example #4 *****");
      // unistroke (a stroke to the left)
      int[] x4 = {20, 18, 16, 14, 12, 10, 9, 8, 7, 6, 5, 4, 3, 3, 2, 2, 1, 1};
      int[] y4 = { 2,  2,  2,  3,  2,  2, 3, 2, 3, 2, 3, 2, 3, 2, 3, 2, 2, 2};

      System.out.println("Sample points... (stroke to the left)");
      for (int i = 0; i < x4.length; ++i)
         System.out.print("{" + x4[i] + "," + y4[i] + "} ");
      System.out.println();

      System.out.println("Try to load a non-existent dictionary file...");
      System.out.println("loadDictionary() return value: " +
         u.loadDictionary("bogus.bogus", CUSTOM1));

      System.out.println("Try to load a dictionary file with bad data...");
      System.out.println("loadDictionary() return value: " +
         u.loadDictionary("Unistroke.java", CUSTOM1));

      System.out.println("Load custom dictionary, 'compass.txt'");
      System.out.println("loadDictionary() return value: " +
         u.loadDictionary("compass.txt", CUSTOM1));

      System.out.println("Dictionary contents...");
      for (int i = 0; i < u.activeDictionary.length; ++i)
         System.out.println(u.activeDictionary[i]);

      System.out.println("Recognized character: " + u.recognize(x4, y4));
      System.out.println("Stroke features: " + u.getFeatures(x3, y3));
   }
}

/*class StrokeDef
{
   private String DEFs;
   private int DEFquadf, DEFquads, DEFquadsl, DEFquadl;
   private double DEFkxmin, DEFkxmax, DEFkymin, DEFkymax;
   private int DEFstartx, DEFstarty, DEFstopx, DEFstopy;

   public StrokeDef(String xs,
      int xquadf, int xquads, int xquadsl, int xquadl,
      double xkxmin, double xkxmax, double xkymin, double xkymax,
      int xstartx, int xstarty, int xstopx, int xstopy)
   {
      DEFs = xs;
      DEFquadf = xquadf;
      DEFquads = xquads;
      DEFquadsl = xquadsl;
      DEFquadl = xquadl;
      DEFkxmin = xkxmin;
      DEFkxmax = xkxmax;
      DEFkymin = xkymin;
      DEFkymax = xkymax;
      DEFstartx = xstartx;
      DEFstarty = xstarty;
      DEFstopx = xstopx;
      DEFstopy = xstopy;
   }

   public String getDEFsymbol() { return DEFs;      }
   public int getDEFquadf()     { return DEFquadf;  }
   public int getDEFquads()     { return DEFquads;  }
   public int getDEFquadsl()    { return DEFquadsl; }
   public int getDEFquadl()     { return DEFquadl;  }
   public double getDEFkxmin()  { return DEFkxmin;  }
   public double getDEFkxmax()  { return DEFkxmax;  }
   public double getDEFkymin()  { return DEFkymin;  }
   public double getDEFkymax()  { return DEFkymax;  }
   public int getDEFstartX()    { return DEFstartx; }
   public int getDEFstartY()    { return DEFstarty; }
   public int getDEFstopX()     { return DEFstopx;  }
   public int getDEFstopY()     { return DEFstopy;  }

   public String toString()
   {
      return DEFs + ", " +
         DEFquadf + ", " + DEFquads + ", " + DEFquadsl + ", " + DEFquadl + ", " +
         DEFkxmin + ", " + DEFkxmax + ", " + DEFkymin + ", " + DEFkymax + ", " +
         DEFstartx + ", " + DEFstarty + ", " + DEFstopx + ", " + DEFstopy;
   }
}*/
