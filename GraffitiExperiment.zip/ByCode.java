import java.util.*;

class ByCode implements Comparator<EncodedWord>
{
   public int compare(EncodedWord ew1, EncodedWord ew2)
   {
      String s1 = ew1.getCode();
      String s2 = ew2.getCode();
      return s1.compareTo(s2);
   }
}