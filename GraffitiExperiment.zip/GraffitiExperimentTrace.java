import java.awt.*;
import java.io.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.*;
import javax.swing.*;
import javax.swing.filechooser.FileFilter;

/**
 * GraffitiExperimentTrace - utility software to plot the stroke trace data in the sd3 files created
 * by GraffitiExperiment.
 * <p>
 * 
 * The sd3 data file processed by this utility must be in a specific format. The first line contains
 * the first "presented text phrase" for a block of trials. This is following by a series of lines,
 * in pairs, containing the trace data (comma delimited). The trace data for each stroke is encoded
 * in two consecutive lines: the <i>x</i> samples, then the <i>y</i> samples. Each line begins with
 * "x=" or "y=", as appropriate. The line following the trace data contains the
 * "transcribed text phrase". This is followed by a separator line containing dashes ("-----"). More
 * data follow, formatted as above, for the remaining phrases in the block.
 * <p>
 * 
 * <a href="GraffitiExperiment-sd3-example.txt">Click here</a> for an example of an sd3 data file.
 * <p>
 * 
 * Invocation:
 * <p>
 * 
 * <pre>
*     PROMPT>java GraffitiExperimentTrace
* </pre>
 * 
 * The program begins with a file chooser showing all the sd3 files in the current directory:
 * <p>
 * 
 * <center><img src="GraffitiExperimentTrace-0.jpg"></center>
 * <p>
 * 
 * After selecting a file, the trace data are loaded and the application frame appears showing the
 * first stroke in the first phrase, for example
 * 
 * <center><img src="GraffitiExperimentTrace-1.jpg"></center>
 * <p>
 * 
 * Clicking "Next" or "Previous" will step through the strokes in the current phrase. Below is a
 * screen snap after several clicks of "Next".
 * 
 * <center><img src="GraffitiExperimentTrace-2.jpg"></center>
 * <p>
 * 
 * As strokes are displayed the progress of text entry appears in the "Progress" text field. This
 * shows the text as it appeared during the original entry of the phrase. This is useful in
 * revealing the mistakes that were made and why they occurred (e.g., a malformed stroke or an
 * unrecognized stroke).
 * <p>
 * 
 * The result of the stroke recognition process is shown in a large font in a text field on the
 * right (see screen snap above). Unrecognized strokes appear as "#". Straight-line strokes
 * conforming to eight compass directions appear as "=N", "=NE", "=E", and so on. An exception is a
 * south or down stroke which appears as "i".
 * <p>
 * 
 * Holding Shift on the system keyboard while clicking "Next" or "Previous" advances to the next or
 * previous phrase in the file.
 * <p>
 * 
 * Data for a new file may be loaded by clicking "Browse...".
 * <p>
 * 
 * @author Scott MacKenzie, 2011-2013
 */
public class GraffitiExperimentTrace
{
	public static void main(String[] args)
	{
		if (args.length > 0)
		{
			System.out.println("Usage: GraffitiExperimentTrace (see API for details)");
			System.exit(0);
		}

		// use look and feel for my system (Win32)
		try
		{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e)
		{
		}

		// String tmp = "GraffitiExperiment-P01-GR-S01-B01.sd3"; // default filename
		GraffitiExperimentTraceFrame frame = new GraffitiExperimentTraceFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("GraffitiExperimentTrace");
		frame.pack();

		// put application in center of screen
		int w = frame.getWidth();
		int h = frame.getHeight();
		Toolkit t = Toolkit.getDefaultToolkit();
		Dimension d = t.getScreenSize();
		frame.setLocation((d.width - w) / 2, (d.height - h) / 2);
		frame.setVisible(true);
	}
}

class GraffitiExperimentTraceFrame extends JFrame implements ActionListener, KeyListener
{
	// the following avoids a "warning" with Java 1.5.0 complier (?)
	static final long serialVersionUID = 42L;

	static int blockCounter = 1;
	private TracePanel tp;
	private JTextField sd3File;
	private JButton browse;
	private JButton next;
	private JButton previous;
	private JButton exit;
	private JFileChooser fc;
	private File f;
	final Font F14 = new Font("sansserif", Font.PLAIN, 14);
	final Font F18 = new Font("sansserif", Font.PLAIN, 18);
	final Font F48 = new Font("sansserif", Font.PLAIN, 48);

	JTextField presentedTextField, transcribedTextField, recognizedGestureField;
	JTextField progressTextField;
	String presentedText, transcribedText, recognizedGesture;
	int phraseIdx, gestureIdx;

	// The sd3 file has the following data hierarchy:
	// -the file contains a series of phrases (a phrase array)
	// -each phrase contains a series of gestures (a gesture array)
	// -each stroke contains a series of points (a point array)
	// and so...
	Phrase[] phraseArray; // array of gesture arrays (+presented/transcribed)
	Gesture[] gestureArray; // array of point arrays
	Point[] pointArray; // array of points

	public GraffitiExperimentTraceFrame()
	{
		// ----------------------------------
		// construct and configure components
		// ----------------------------------

		fc = new JFileChooser(new File("."));
		final String[] EXTENSIONS = { ".sd3" };
		fc.addChoosableFileFilter(new MyFileFilter(EXTENSIONS));

		previous = new JButton("Previous");
		next = new JButton("Next");
		exit = new JButton("Exit");

		browse = new JButton("Browse...");
		previous.setFont(F18);
		next.setFont(F18);
		exit.setFont(F18);
		browse.setFont(F18);

		sd3File = new JTextField(5);
		sd3File.setEditable(false);
		sd3File.setBackground(Color.LIGHT_GRAY);
		sd3File.setFont(F14);
		JLabel sd3FileLabel = new JLabel("File: ", SwingConstants.RIGHT);
		sd3FileLabel.setFont(F14);

		presentedTextField = new JTextField(30);
		presentedTextField.setEditable(false);
		presentedTextField.setBackground(Color.LIGHT_GRAY);
		presentedTextField.setFont(F14);
		JLabel presentedTextFieldLabel = new JLabel("Presented: ", SwingConstants.RIGHT);
		presentedTextFieldLabel.setFont(F14);

		transcribedTextField = new JTextField(30);
		transcribedTextField.setEditable(false);
		transcribedTextField.setBackground(Color.LIGHT_GRAY);
		transcribedTextField.setFont(F14);
		JLabel transcribedTextFieldLabel = new JLabel("Transcribed: ", SwingConstants.RIGHT);
		transcribedTextFieldLabel.setFont(F14);

		progressTextField = new JTextField(30);
		progressTextField.setEditable(false);
		progressTextField.setBackground(Color.LIGHT_GRAY);
		progressTextField.setFont(F14);
		JLabel progressTextFieldLabel = new JLabel("Progress: ", SwingConstants.RIGHT);
		progressTextFieldLabel.setFont(F14);

		recognizedGestureField = new JTextField(3);
		recognizedGestureField.setEditable(false);
		recognizedGestureField.setBackground(Color.LIGHT_GRAY);
		recognizedGestureField.setFont(F48);
		recognizedGestureField.setHorizontalAlignment(SwingConstants.CENTER);

		tp = new TracePanel(); // also presents file chooser to load data
		tp.setBorder(BorderFactory.createLineBorder(Color.gray));
		tp.setPreferredSize(new Dimension(400, 300));

		// -------------
		// add listeners
		// -------------

		next.addActionListener(this);
		previous.addActionListener(this);
		exit.addActionListener(this);
		browse.addActionListener(this);
		this.addKeyListener(this);

		// ------------------
		// arrange components
		// ------------------

		JPanel ptLeft = new JPanel(new GridLayout(0, 1));
		ptLeft.add(sd3FileLabel);
		ptLeft.add(presentedTextFieldLabel);
		ptLeft.add(transcribedTextFieldLabel);
		ptLeft.add(progressTextFieldLabel);

		JPanel ptRight = new JPanel(new GridLayout(0, 1));
		ptRight.add(sd3File);
		ptRight.add(presentedTextField);
		ptRight.add(transcribedTextField);
		ptRight.add(progressTextField);

		JPanel pt2 = new JPanel();
		pt2.setLayout(new BorderLayout());
		pt2.add(ptLeft, "West");
		pt2.add(ptRight, "East");
		// pt2.setBorder(BorderFactory.createLineBorder(Color.gray));

		JPanel pt3 = new JPanel();
		pt3.add(pt2);
		pt3.add(recognizedGestureField);

		JPanel pn = new JPanel();
		pn.add(previous);
		pn.add(next);
		pn.setBorder(BorderFactory.createLineBorder(Color.gray));

		JPanel p1 = new JPanel();
		p1.setLayout(new BoxLayout(p1, BoxLayout.X_AXIS));
		p1.add(Box.createRigidArea(new Dimension(10, 0)));
		p1.add(browse);
		p1.add(Box.createRigidArea(new Dimension(10, 0)));
		p1.add(previous);
		p1.add(Box.createRigidArea(new Dimension(10, 0)));
		p1.add(next);
		p1.add(Box.createRigidArea(new Dimension(10, 0)));
		p1.add(exit);
		p1.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

		JPanel p = new JPanel();
		p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
		p.add(tp);
		p.add(pt3);
		p.add(p1);
		p.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		this.pack();
		this.setContentPane(p);
	}

	// -------------------------------
	// implement ActionListener method
	// -------------------------------

	@Override
	public void actionPerformed(ActionEvent ae)
	{
		Object source = ae.getSource();
		boolean shift = (ae.getModifiers() & ActionEvent.SHIFT_MASK) == 0 ? false : true;
		if (source == next && shift)
			tp.nextPhrase();
		else if (source == next && !shift)
			tp.nextStroke();
		else if (source == previous && shift)
			tp.previousPhrase();
		else if (source == previous && !shift)
			tp.previousStroke();
		else if (source == exit)
			System.exit(0);
		else if (source == browse)
		{
			// tp = new TracePanel();
			// popup file chooser dialog to get sd3 file
			// String fileName = "";
			if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION)
			{
				f = fc.getSelectedFile();
				tp.loadData(f.getPath());
				// fileName = f.getName();
				sd3File.setText(f.getName());
				phraseIdx = 0;
				gestureIdx = 0;
				presentedTextField.setText(phraseArray[0].presentedPhrase);
				transcribedTextField.setText(phraseArray[0].transcribedPhrase);
				tp.update();
			} // else
				// fileName = ""; // if Cancel, use null string for filename
		}
	}

	public void keyPressed(KeyEvent ke)
	{
	} // do nothing

	public void keyReleased(KeyEvent ke)
	{
	} // do nothing

	public void keyTyped(KeyEvent ke)
	{
		System.out.println(ke.getKeyChar());
	}

	// -----------------------------------------
	// A class to display the traces
	// -----------------------------------------

	class TracePanel extends JPanel implements ActionListener
	{
		private static final long serialVersionUID = 1L;

		String fileName = "";
		Unistroke u;

		public void actionPerformed(ActionEvent ae)
		{
		}

		TracePanel()
		{
			gestureIdx = 0;
			phraseIdx = 0;
			this.setBackground(Color.pink);
			u = new Unistroke(); // use default GRAFFITI mode (for now)

			// popup file chooser dialog to get sd3 file
			if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION)
			{
				f = fc.getSelectedFile();
				loadData(f.getPath());
				fileName = f.getName();
				sd3File.setText(f.getName());
				phraseIdx = 0;
				gestureIdx = 0;
				presentedTextField.setText(phraseArray[0].presentedPhrase);
				transcribedTextField.setText(phraseArray[0].transcribedPhrase);
				update();
			} else
				fileName = ""; // if Cancel, use null string for filename
		}

		public void drawStroke(Graphics g)
		{
			// avoid crash if "Cancel" selected from file chooser (1st time only)
			if (phraseArray == null || phraseArray.length == 0)
				return;
			Point[] pp = phraseArray[phraseIdx].g[gestureIdx].p;
			
			// new code to ensure strokes are painted in the center of the panel			 
			double xMin = 10000;
			double xMax = 0;
			double yMin = 10000;
			double yMax = 0;
			for (int i = 0; i < pp.length; ++i)
			{
				xMin = pp[i].x < xMin ? pp[i].x : xMin;
				yMin = pp[i].y < yMin ? pp[i].y : yMin;
				xMax = pp[i].x > xMax ? pp[i].x : xMax;
				yMax = pp[i].y > yMax ? pp[i].y : yMax;
			}
			int xOffset = (int)(this.getWidth() / 2.0 - (xMin + (xMax - xMin) / 2.0));
			int yOffset = (int)(this.getHeight() / 2.0 - (yMin + (yMax - yMin) / 2.0));

			Graphics2D g2 = (Graphics2D)g;
			final Stroke INK_STROKE = new BasicStroke(5.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
			g2.setStroke(INK_STROKE);

			for (int j = 0; j < pp.length - 1; ++j)
			{
				int x1 = (int)pp[j].getX() + xOffset;
				int y1 = (int)pp[j].getY() + yOffset;
				int x2 = (int)pp[j + 1].getX() + xOffset;
				int y2 = (int)pp[j + 1].getY() + yOffset;
				Line2D.Double inkSegment = new Line2D.Double(x1, y1, x2, y2);
				g2.setColor(new Color(0, 0, 128)); // deep blue
				g2.draw(inkSegment); // draw it!
			}
			// draw circle at pen-down point (fix!)
			int x = (int)pp[0].getX() - 2 + xOffset;
			int y = (int)pp[0].getY() - 2 + yOffset;
			Ellipse2D.Double e = new Ellipse2D.Double(x, y, 10, 10);
			g2.setColor(new Color(0, 0, 128));
			g2.draw(e);
			g2.fill(e);
		}

		// =========================
		// ===== LOAD SD3 DATA =====
		// =========================
		private void loadData(String fileArg)
		{
			gestureIdx = 0;
			phraseIdx = 0;
			BufferedReader br = null;
			try
			{
				br = new BufferedReader(new FileReader(fileArg));
			} catch (FileNotFoundException e)
			{
				JLabel tmp = new JLabel("File not found: " + fileArg);
				tmp.setFont(F18);
				JOptionPane.showMessageDialog(this, tmp, "Error", JOptionPane.ERROR_MESSAGE);
				System.exit(0);
			}

			Vector<Phrase> p = null;
			Vector<Gesture> g = null;
			String presentedPhrase;
			String transcribedPhrase = "?";
			String line, xLine, yLine;
			line = "";
			try
			{
				p = new Vector<Phrase>();
				while ((line = br.readLine()) != null)
				{
					presentedPhrase = line;
					g = new Vector<Gesture>();
					while ((line = br.readLine()) != null && line.substring(0, 2).equals("x="))
					{
						xLine = line;
						yLine = br.readLine().trim();

						// delete commas at end of lines (if any)
						if (xLine.charAt(xLine.length() - 1) == ',')
							xLine = xLine.substring(0, xLine.length() - 1);
						if (yLine.charAt(yLine.length() - 1) == ',')
							yLine = yLine.substring(0, yLine.length() - 1);

						StringTokenizer stx = new StringTokenizer(xLine, ",");
						StringTokenizer sty = new StringTokenizer(yLine, ",");
						stx.nextToken(); // x= (trace data begins with next token)
						sty.nextToken(); // y= (skip)

						pointArray = new Point[stx.countTokens()];
						for (int i = 0; i < pointArray.length; ++i)
						{
							int x = (int)Math.round(Double.parseDouble(stx.nextToken()));
							int y = (int)Math.round(Double.parseDouble(sty.nextToken()));
							pointArray[i] = new Point(x, y);
						}
						g.add(new Gesture(pointArray));
					}

					if (g.isEmpty()) // ...likely a data format error
						throw new IOException();

					transcribedPhrase = line;
					br.readLine(); // ------ separator
					gestureArray = new Gesture[g.size()];
					g.copyInto(gestureArray);
					if (gestureArray.length > 0)
						p.add(new Phrase(presentedPhrase, transcribedPhrase, gestureArray));
				}
				phraseArray = new Phrase[p.size()];
				p.copyInto(phraseArray); // whew!!!
			} catch (IOException e) // likely a data format error
			{
				String message = "Data format error!\nFile: " + fileArg + "\nLine: " + line
						+ "\nConsult API for format requirements.";
				JTextArea tmp = new JTextArea(message);
				tmp.setFont(F14);
				tmp.setBackground(new Color(212, 208, 200));
				JOptionPane.showMessageDialog(this, tmp, "Error", JOptionPane.ERROR_MESSAGE);
				System.exit(0);
			}

			this.repaint();
			return;
		}

		public String getFileName()
		{
			return fileName;
		}

		public void clear()
		{
			this.repaint();
		}

		@Override
		public void paintComponent(Graphics g)
		{
			super.paintComponent(g); // paint background
			this.paintHeader(g);
			this.drawStroke(g);
		}

		private void paintHeader(Graphics g)
		{
			// avoid crash if "Cancel" selected from file chooser (1st time only)
			String header = "no data";
			if (phraseArray != null && phraseArray.length > 0)
				header = "Stroke " + (gestureIdx + 1) + " of " + phraseArray[phraseIdx].g.length;

			Graphics2D g2 = (Graphics2D)g;
			g2.setColor(new Color(128, 0, 0));
			g2.setFont(new Font("SansSerif", Font.BOLD, 24));
			FontMetrics fm = g2.getFontMetrics();
			int width = fm.stringWidth(header);
			int height = fm.getHeight();
			int w = this.getWidth();
			g2.drawString(header, w / 2 - width / 2, height);
		}

		// display trace data for the next block of trials
		public void nextStroke()
		{
			if (gestureIdx < phraseArray[phraseIdx].g.length - 1)
				++gestureIdx;
			update();
		}

		// display trace data for previous block of trials
		public void previousStroke()
		{
			if (gestureIdx > 0)
				--gestureIdx;
			update();
		}

		public void nextPhrase()
		{
			if (phraseIdx < phraseArray.length - 1)
			{
				gestureIdx = 0;
				++phraseIdx;
			}
			presentedTextField.setText(phraseArray[phraseIdx].presentedPhrase);
			transcribedTextField.setText(phraseArray[phraseIdx].transcribedPhrase);
			progressTextField.setText("");
			update();
		}

		public void previousPhrase()
		{
			if (phraseIdx > 0)
			{
				gestureIdx = 0;
				--phraseIdx;
			}
			presentedTextField.setText(phraseArray[phraseIdx].presentedPhrase);
			transcribedTextField.setText(phraseArray[phraseIdx].transcribedPhrase);
			progressTextField.setText("");
			update();
		}

		void update()
		{
			String tmp = "";
			for (int i = 0; i <= gestureIdx; ++i)
			{
				Point[] p = phraseArray[phraseIdx].g[i].p;
				String s = u.recognize(p, p.length);
				recognizedGestureField.setText(s);

				if (s.length() == 1 && !s.equals("#")) //
					tmp += s;
				else if (s.equals("=E"))
					tmp += " ";
				else if (s.equals("=W"))
					tmp = tmp.substring(0, tmp.length() - 1);
			}
			progressTextField.setText(tmp);
			this.repaint();
		}
	}

	// Gesture -- an array of points corresponding to a stroke.
	class Gesture
	{
		public Point[] p;

		Gesture(Point[] pArg)
		{
			p = pArg;
		}
	}

	// Phrase -- an array of gestures and the corresponding presented and
	// transcribed text phrases.
	class Phrase
	{
		public String presentedPhrase;
		public String transcribedPhrase;
		public Gesture[] g;

		Phrase(String presentedPhraseArg, String transcribedPhraseArg, Gesture[] gArg)
		{
			presentedPhrase = presentedPhraseArg;
			transcribedPhrase = transcribedPhraseArg;
			g = gArg;
		}
	}

	/**
	 * A class to extend the FileFilter class (which is abstract) and implement the 'accept' and
	 * 'getDescription' methods.
	 */
	class MyFileFilter extends FileFilter
	{
		private String[] s;

		MyFileFilter(String[] sArg)
		{
			s = sArg;
		}

		// determine which files to display in the chooser
		@Override
		public boolean accept(File fArg)
		{
			// if it's a directory, show it
			if (fArg.isDirectory())
				return true;

			// if the filename contains the extension, show it
			for (int i = 0; i < s.length; ++i)
				if (fArg.getName().toLowerCase().indexOf(s[i].toLowerCase()) > 0)
					return true;

			// filter out everything else
			return false;
		}

		@Override
		public String getDescription()
		{
			String tmp = "";
			for (int i = 0; i < s.length; ++i)
				tmp += "*" + s[i] + " ";

			return tmp;
		}
	}
}
