

class StrokeDef {
    private String DEFs;
    private int DEFquadf;
    private int DEFquads;
    private int DEFquadsl;
    private int DEFquadl;
    private double DEFkxmin;
    private double DEFkxmax;
    private double DEFkymin;
    private double DEFkymax;
    private int DEFstartx;
    private int DEFstarty;
    private int DEFstopx;
    private int DEFstopy;
    
    public StrokeDef(String s, int i, int j, int k, int l, double d,
            double d1, double d2, double d3, int i1,
            int j1, int k1, int l1) {
        DEFs = s;
        DEFquadf = i;
        DEFquads = j;
        DEFquadsl = k;
        DEFquadl = l;
        DEFkxmin = d;
        DEFkxmax = d1;
        DEFkymin = d2;
        DEFkymax = d3;
        DEFstartx = i1;
        DEFstarty = j1;
        DEFstopx = k1;
        DEFstopy = l1;
    }
    
    public String getDEFsymbol() {
        return DEFs;
    }
    
    public int getDEFquadf() {
        return DEFquadf;
    }
    
    public int getDEFquads() {
        return DEFquads;
    }
    
    public int getDEFquadsl() {
        return DEFquadsl;
    }
    
    public int getDEFquadl() {
        return DEFquadl;
    }
    
    public double getDEFkxmin() {
        return DEFkxmin;
    }
    
    public double getDEFkxmax() {
        return DEFkxmax;
    }
    
    public double getDEFkymin() {
        return DEFkymin;
    }
    
    public double getDEFkymax() {
        return DEFkymax;
    }
    
    public int getDEFstartX() {
        return DEFstartx;
    }
    
    public int getDEFstartY() {
        return DEFstarty;
    }
    
    public int getDEFstopX() {
        return DEFstopx;
    }
    
    public int getDEFstopY() {
        return DEFstopy;
    }
    
    public String toString() {
        return DEFs + ", " + DEFquadf + ", " + DEFquads + ", " + DEFquadsl + ", " + DEFquadl + ", " + DEFkxmin + ", " + DEFkxmax + ", " + DEFkymin + ", " + DEFkymax + ", " + DEFstartx + ", " + DEFstarty + ", " + DEFstopx + ", " + DEFstopy;
    }
}
