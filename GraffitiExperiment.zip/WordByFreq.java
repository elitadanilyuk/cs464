import java.util.*;

public class WordByFreq implements Comparator<Word>
{
   public int compare(Word w1, Word w2)
   {
      double d1 = w1.getFreq();
      double d2 = w2.getFreq();
      return (int)(d2 - d1);
   }
}
