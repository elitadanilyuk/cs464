import javax.sound.sampled.*;
import javax.swing.*;
import javax.swing.Timer;
import javax.swing.border.*;
import java.awt.geom.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.URL;
import java.util.*;

/**
 * <h1>GraffitiExperiment</h1>
 * 
 * <h3>Summary</h3>
 * 
 * <ul>
 * <li>Experiment software for text entry using handwriting recognition.
 * <p>
 * 
 * <li>For demonstration, mouse input can be used, but finger or stylus input is more appropriate and
 * should be used if possible.
 * <p>
 * 
 * <li>Handwriting is performed using <i>Graffiti</i> or <i>Unistrokes</i> with stroke recognition using
 * the <code>Unistroke</code> class. Consult the API for the <code>Unistroke</code> class for
 * details on the recognition process (<a href="Unistroke.html">Click here</a>).
 * <p>
 * </ul>
 * 
 * <h3>Related References (oldest to newest)</h3>
 * 
 * <ul>
 * <li>"Stylus typing with a stylus", by Goldberg and Richardson (<i>CHI '93</i>). This is the
 * original paper where the unistrokes concept was first described. Download this paper from the ACM
 * Digital Library.
 * <p>
 * 
 * <li><a href="http://www.yorku.ca/mack/GI97a.html">The immediate usability of Graffiti</a>, by
 * MacKenzie and Zhang (<i>GI '97</i>). This is an early evaluation of <i>Graffiti</i>, which done
 * shortly after the commercial release of <i>Graffiti</i> by Palm Computing.
 * <p>
 * 
 * <li><a href="http://www.yorku.ca/mack/chi2008b.html">Graffiti vs. Unistrokes: An empirical
 * comparison</a>, by Castellucci and MacKenzie (<i>CHI 2008</i>). This paper presents an
 * experimental comparison between <i>Graffiti</i> and <i>Unistrokes</i>.
 * <p>
 * 
 * <li><a href="http://www.yorku.ca/mack/nordichi2006.html">Unipad: Single-stroke text entry with
 * language-based acceleration</a>, by MacKenzie, Chen, and Oniszczak (<i>NordiCHI 2006</i>). This
 * paper presents an experimental evaluation of a <i>Graffiti</i>-based text entry method enhanced
 * with suffix completion, word completion, and frequent-word prompting.
 * <p>
 * 
 * <li><a href="http://www.yorku.ca/mack/tic2009.html">Eyes-free text entry on a touchscreen
 * phone</a>, by Tinwala and MacKenzie (<i>TIC-STH 2009</i>). This paper presents an eyes-free text
 * entry method using <i>Graffiti</i> strokes on a touchscreen phone. Input is augmented with,
 * speech, auditory, and vibrotactile feedback.
 * <p>
 * 
 * <li><a href="http://www.yorku.ca/mack/nordichi2010.html">Eyes-free text entry with error
 * correction on touchscreen mobile devices</a>, by Tinwala and MacKenzie (<i>NordiCHI 2010</i>).
 * This paper is a follow-on to the paper above with a focus on automatic error correction.
 * <p>
 * 
 * <li><a href="http://www.yorku.ca/mack/chi2012.html">Reducing visual demand for gestural text
 * input on touchscreen devices</a>, by MacKenzie and Castellucci (<i>CHI 2012</i>). This paper
 * introduces the Frame Model of Visual Attention. The model is explained and demonstrated using a
 * version of GraffitiExperiment running on an Android device.
 * </ul>
 * <p>
 * 
 * <h3>Running the Experiment Software</h3>
 * 
 * <a href="http://www.yorku.ca/mack/HCIbook/Running/">Click here</a> for instructions on
 * launching/running the application.
 * <p>
 * 
 * <h3>Setup Parameters</h3>
 * 
 * Upon launching, the program presents a setup dialog:
 * <p>
 * 
 * <center> <img src="GraffitiExperiment-1.jpg"> </center>
 * <p>
 * 
 * The default parameter settings are read from a configuration file called
 * <code>GraffitiExperiment.cfg</code>. This file is created automatically when the application is
 * launched for the first time. The default parameter settings may be changed through the setup
 * dialog. The setup parameters are as follows:
 * <p>
 * 
 * <blockquote>
 * <table border="1" cellspacing="0" cellpadding="6" valign="top">
 * <tr bgcolor="#cccccc">
 * <th>Parameter
 * <th>Description
 * 
 * <tr valign="top">
 * <td>Participant Code
 * <td>Identifies the current participant. This is used in forming the names for
 * the output data files. Also, the sd2 output data file includes a column with the participant
 * code.
 * <p>
 * 
 * <tr valign="top">
 * <td>Condition Code
 * <td>An arbitrary code used to associate a test condition with this invocation.
 * This parameter might be useful if the software is used in an experiment where a condition is not
 * inherently part of the application (e.g., Gender &rarr; male, female, Input Device &rarr;
 * gamepad, keyboard). The condition code is used in forming the name for the output data file.
 * Also, the sd2 output data file contains a column with the condition code.
 * <p>
 * 
 * <tr valign="top">
 * <td>Session Code
 * <td>Identifies the session. Useful if testing proceeds over multiple sessions to
 * gauge the progression of learning.
 * <p>
 * 
 * Note: The setup dialog does not include an entry for "Block code". The block code is generated
 * automatically by the software.
 * <p>
 *  
 * <tr valign="top">
 * <td>Number of Phrases
 * <td>Specifies the number of phrases presented to the participant in the
 * current block.
 * <p>
 * 
 * <tr valign="top">
 * <td>Phrases File
 * <td>Specifies a file containing phrases of text to be presented to participants
 * for entry. Phrases are drawn from the file at random. Typically, <a
 * href="phrases2.txt">phrases2.txt</a> is used. This is the phrase set published by MacKenzie and
 * Soukoreff in 2003 (<a href="http://www.yorku.ca/mack/chi03b.html">click here</a>). The other
 * files in the drop-down list are <a href="phrases2.txt">phrases2.txt</a>, <a
 * href="helloworld.txt">helloworld.txt</a>, <a href="helloworld2.txt">helloworld2.txt</a>, <a
 * href="quickbrownfox.txt">quickbrownfox.txt</a>, <a href="phrases.txt">phrases.txt</a>, <a
 * href="phrases100.txt">phrases100.txt</a>, <a href="vowells.txt">vowells.txt</a>, and <a
 * href="alphabet.txt">alphabet.txt</a>.
 * <p>
 * 
 * <tr valign="top">
 * <td>Entry Mode
 * <td>Specifies the stroke alphabet Although the software is primarily intended for
 * <i>Graffiti</i> evaluations, three other modes are supported:
 * <p>
 * 
 * <center> <img src="GraffitiExperiment-1b.jpg"> </center>
 * <p>
 * 
 * Details on defining a custom set of strokes are found in the API for the <code>Unistroke</code>
 * class.
 * <p>
 * 
 * <tr valign="top">
 * <td>Show Gesture Set
 * <td>A checkbox item that determines whether or not an image showing the
 * gesture set is shown in the experiment UI (see below).
 * <p>
 * </table>
 * </blockquote>
 * <p>
 * 
 * <h3>Program Operation</h3>
 * 
 * Upon clicking OK in the setup dialog, the application launches:
 * <p>
 * 
 * <center> <img src="GraffitiExperiment-2.jpg"> </center>
 * <p>
 * 
 * 
 * After clicking "Begin", a phrase is selected at random from the phrase set and displayed in the
 * top text field. Timing begins at the beginning of the first stroke. Below is a screen snap of the
 * experiment dialog after some user input:
 * <p>
 * 
 * <center> <img src="GraffitiExperiment-3.jpg"> </center>
 * <p>
 * 
 * The user enters the phrase, stroke by stroke. Entry continues until the user clicks "Enter".
 * Timing is stopped when "Enter" is clicked. Results of the text entry process appear in a popup
 * dialog after each phrase. Below is an example:
 * <p>
 * 
 * <center> <img src="GraffitiExperiment-5.jpg"> </center>
 * <p>
 * 
 * Although it is not apparent in the popup dialog above, a number of errors were committed which
 * were then corrected. This is revealed in the high KSPC value (KSPC = 1.5). The exact nature of
 * the errors may be investigated by examining the output data files or through a special trace
 * utility (see below).
 * <p>
 * 
 * <h3>Output Data Files</h3>
 * 
 * Output data are saved in files for follow-up analyses. Three "sd" (summary data) files are
 * created. The sd1 file contains data on a stroke by stroke basis, including timestamps. The sd2
 * file contains summary data for each phrase, one line per phrase. The sd3 file contains trace data
 * (x/y sample points) for each each stroke. A separate utility, <a
 * href="GraffitiExperimentTrace.html">GraffitiExperimentTrace</a>, is available to facilitate
 * viewing the trace data.
 * <p>
 * 
 * 
 * Example data files follow:
 * <p>
 * 
 * <ul>
 * <li><a href="GraffitiExperiment-sd1-example.txt">sd1 example</a>
 * <li><a href="GraffitiExperiment-sd2-example.txt">sd2 example</a>
 * <li><a href="GraffitiExperiment-sd3-example.txt">sd3 example</a>
 * </ul>
 * 
 * The data in the sd2 file are full-precision, comma-delimited. Importing into a spreadsheet
 * application provides a convenient method to examine the data on a phrase-by-phrase basis. Below
 * is an example of how the data might look after importing into Microsoft <i>Excel</i>: (click to enlarge)
 * <p>
 * 
 * <center> <a href="GraffitiExperiment-6.jpg"><img src="GraffitiExperiment-6.jpg" width=800></a>
 * </center>
 * <p>
 * 
 * <a href="GraffitiExperiment-example.xlsx">Click here</a> to open the spreadsheet.
 * <p>
 * 
 * Actual output files use "GraffitiExperiment" as the base filename. This is followed by the
 * participant code, the mode, the condition code, the session code, and the block code, for
 * example, <code>GraffitiExperiment-P99-GR-CC-S01-B01.sd1</code> ("GR" = Graffiti mode).
 * <p>
 * 
 * <h3>Miscellaneous</h3>
 * 
 * When using this program in an experiment, it is a good idea to terminate all other applications
 * and disable the system's network connection. This will maintain the integrity of the data
 * collected and ensure that the program runs without hesitations.
 * <p>
 * 
 * @author Scott MacKenzie, 2009-2015
 * @author Steven Castellucci, 2014
 */
public class GraffitiExperiment
{
	final static String APP_NAME = "GraffitiExperiment";
	final static int PARAMETERS = 7; // must equal the number of parameters defined below

	// setup parameters (1st is default)
	final static String[] PARTICIPANT_CODES = { "P00", "P01", "P02", "P03", "P04", "P05", "P06", "P07", "P08", "P09",
			"P10", "P11", "P12", "P13", "P14", "P15", "P16", "P17", "P18", "P19", "P20", "P21", "P22", "P23", "P24",
			"P25", "P26", "P27", "P28", "P29", "P30" };
	final static String[] CONDITION_CODE = { "C00" };
	final static String[] SESSION_CODES = { "S00", "S01", "S02", "S03", "S04", "S05", "S06", "S07", "S08", "S09",
			"S10", "S11", "S12", "S13", "S14", "S15", "S16", "S17", "S18", "S19", "S20", "S21", "S22", "S23", "S24",
			"S25", "S26", "S27", "S28", "S29", "S30" };
	final static String[] NUMBER_OF_PHRASES = { "5" };
	final static String[] PHRASES_FILE = { "phrases2.txt", "quickbrownfox.txt", "alphabet.txt" };
	final static String[] ENTRY_MODE = { "Graffiti", "Unistrokes", "Digits", "Custom" };
	final static String[] SHOW_GESTURE_SET = { "true" };

	public static void main(String[] args) throws IOException
	{
		// use Win32 look and feel
		try
		{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e)
		{
		}

		// read default configuration from file
		// specify other files to read (needed, maybe, if executing from the jar file)
		String[] otherFiles = { "phrases2.txt", "quickbrownfox.txt", "alphabet.txt",
				GraffitiExperimentGui.GRAFFITI_IMAGE, GraffitiExperimentGui.UNISTROKES_IMAGE };

		/*
		 * Define the default parameters settings. These are only used if the .cfg file does not
		 * exit, such as when the application is launched for the 1st time.
		 */
		String[] defaultParameters = new String[PARAMETERS];
		defaultParameters[0] = PARTICIPANT_CODES[0];
		defaultParameters[1] = CONDITION_CODE[0];
		defaultParameters[2] = SESSION_CODES[0];
		defaultParameters[3] = NUMBER_OF_PHRASES[0];
		defaultParameters[4] = PHRASES_FILE[0];
		defaultParameters[5] = ENTRY_MODE[0];
		defaultParameters[6] = SHOW_GESTURE_SET[0];

		Configuration c = Configuration.readConfigurationData(APP_NAME, defaultParameters, otherFiles);
		if (c == null)
		{
			System.out.println("Error reading configuration data from " + APP_NAME + ".cfg!");
			System.exit(0);
		}

		// -----------------------
		// create setup parameters
		// -----------------------

		SetupItemInfo[] sii = new SetupItemInfo[7];
		sii[0] = new SetupItemInfo(SetupItem.COMBO_BOX, "Participant code ", PARTICIPANT_CODES);
		sii[1] = new SetupItemInfo(SetupItem.TEXT_FIELD, "Condition code ", CONDITION_CODE);
		sii[2] = new SetupItemInfo(SetupItem.COMBO_BOX, "Session code ", SESSION_CODES);
		sii[3] = new SetupItemInfo(SetupItem.TEXT_FIELD, "Number of phrases ", NUMBER_OF_PHRASES);
		sii[4] = new SetupItemInfo(SetupItem.COMBO_BOX, "Phrases file ", PHRASES_FILE);
		sii[5] = new SetupItemInfo(SetupItem.COMBO_BOX, "Entry mode ", ENTRY_MODE);
		sii[6] = new SetupItemInfo(SetupItem.CHECK_BOX, "Show gesture set ", SHOW_GESTURE_SET);

		// use setup to allow changes to default configuration
		Setup s = new Setup(null, c, APP_NAME, sii);
		s.showSetup(null);

		GraffitiExperimentGui screen = new GraffitiExperimentGui(c);
		screen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		screen.setTitle("Graffiti Experiment");
		screen.pack();

		// put application in center of screen
		int w = screen.getWidth();
		int h = screen.getHeight();
		Toolkit t = Toolkit.getDefaultToolkit();
		Dimension d = t.getScreenSize();
		screen.setLocation((d.width - w) / 2, (d.height - h) / 2);
		screen.setVisible(true);
	}
}

class GraffitiExperimentGui extends JFrame implements MouseListener, MouseMotionListener, ActionListener
{
	private static final long serialVersionUID = 1L;
	final static String GRAFFITI = "GRAFFITI";
	final static String UNISTROKES = "UNISTROKES";
	final static String CUSTOM = "CUSTOM";
	final static String DIGITS = "DIGITS";

	final static String GRAFFITI_IMAGE = "GraffitiExperiment-graffiti.gif";
	final static String UNISTROKES_IMAGE = "GraffitiExperiment-unistrokes.gif";

	// setup parameters
	String participantCode, conditionCode;
	String sessionCode;
	String blockCode;
	int numberOfPhrases;
	String phrasesFile;
	String entryMode;
	boolean showGestureSet;
	// ...end setup parameters

	final int MAX_SAMPLES = 500;

	// JTextField xMotion;
	// JTextField yMotion;
	Point[] stroke;
	Unistroke u;
	int sampleCount;
	int strokeCount;

	int phraseCount;
	boolean phoneLayout = false;
	boolean qwertyLayout = false;
	Timer t;
	int tapCount = 0;
	String newKey = "";
	String lastKey = "";
	String m = "";

	String build = "";
	String[] candidates = null;

	Color enabledBackgroundColor = new Color(220, 220, 220);
	Color disabledBackgroundColor = new Color(180, 180, 180);
	int candidateIndex;

	final String LOWERCASE = "abc";
	final String UPPERCASE = "ABC";
	String caseMode = LOWERCASE;
	JLabel caseLabel = new JLabel();
	JLabel entryModeLabel = new JLabel();

	EncodedWord[] ew;
	final int MAX_CANDIDATES = 10;
	JTextField[] queries = new JTextField[MAX_CANDIDATES];
	TextMessage tm = new TextMessage();

	final Font TEXT_FIELD_FONT = new Font("sansserif", Font.BOLD, 18);
	String[] keyLetters = new String[10];
	String[] keyLabels = new String[12];

	PaintPanel graffitiPanel;
	JPanel outerPanel;

	JTextField presentedText;
	JTextField transcribedText;
	Random r = new Random();
	Vector<Sample> samples;

	long t1, t2;
	int count; // count keystrokes per phrase
	String[] phrases;
	BufferedWriter sd1File, sd2File, sd3File;
	Configuration c;

	Clip unrecognizedClip;
	Clip recognizedClip;
	Clip ambiguousSelectionClip;

	boolean tap;
	Image graffitiImage, unistrokesImage;

	JDialog resultsDialog;
	JOptionPane resultsPane;
	JTextArea resultsArea;

	JButton begin;
	JButton enter;

	String[] dict;

	// constructor
	GraffitiExperimentGui(Configuration cArg) throws IOException
	{
		// Initialize setup parameters
		c = cArg;
		participantCode = c.getConfigurationParameter(0);
		conditionCode = c.getConfigurationParameter(1);
		sessionCode = c.getConfigurationParameter(2);
		// Note: block code generated automatically (see below)
		numberOfPhrases = Integer.parseInt(c.getConfigurationParameter(3));
		phrasesFile = c.getConfigurationParameter(4);
		entryMode = c.getConfigurationParameter(5).toUpperCase();
		showGestureSet = Boolean.valueOf(c.getConfigurationParameter(6));

		// initialize sound clips
		unrecognizedClip = initSound("miss.wav");
		recognizedClip = initSound("type.wav");
		ambiguousSelectionClip = initSound("undo.wav");

		phraseCount = numberOfPhrases;

		samples = new Vector<Sample>();

		// open disk file for input
		BufferedReader inFile = new BufferedReader(new FileReader(phrasesFile));
		Vector<String> v = new Vector<String>();
		String s;
		while ((s = inFile.readLine()) != null)
			v.addElement(s.toLowerCase());
		phrases = new String[v.size()];
		v.copyInto(phrases);

		// read dictionary (for spell check)
		// dict = getDictionary("d2phrases2-word.txt");
		// if (dict == null)
		// System.exit(0);
		// Arrays.sort(dict);

		// -----------------------
		// initialize output files
		// -----------------------

		blockCode = "";
		int blockCodeNumber = 0;
		String outputFile = "GraffitiExperiment-" + participantCode + "-" + conditionCode + "-" + sessionCode;
		String s1 = "";
		String s2 = "";
		String s3 = "";
		do // find next available block code
		{
			++blockCodeNumber;
			blockCode = blockCodeNumber < 10 ? "B0" + blockCodeNumber : "B" + blockCodeNumber;
			s1 = outputFile + "-" + blockCode + ".sd1";
			s2 = outputFile + "-" + blockCode + ".sd2";
			s3 = outputFile + "-" + blockCode + ".sd3";
		} while (new File(s1).exists());

		JLabel warning = new JLabel("Output data files exist. Overwrite?");
		warning.setFont(new Font("sansserif", Font.PLAIN, 16));
		final Object[] OPTIONS = { "No", "Yes" };
		if ((new File(s1)).exists() || (new File(s2)).exists())
		{
			if (JOptionPane.showOptionDialog(this, warning, "Caution", JOptionPane.YES_NO_OPTION,
					JOptionPane.QUESTION_MESSAGE, null, OPTIONS, OPTIONS[0]) == 0)
			{
				System.exit(1);
			}
		}
		sd1File = new BufferedWriter(new FileWriter(s1));
		sd2File = new BufferedWriter(new FileWriter(s2));
		sd3File = new BufferedWriter(new FileWriter(s3));

		// output header in sd2 file
		String header = "App,Participant,Mode,Condition,Session,Block,"
				+ "Keystrokes,Characters,Time_(s),MSD,Speed_(wpm),Error_rate_(%),KSPC\n";
		sd2File.write(header, 0, header.length());
		sd2File.flush();

		setBackground(Color.white);
		presentedText = new JTextField();
		transcribedText = new JTextField();

		presentedText.setFont(TEXT_FIELD_FONT);
		presentedText.setEditable(false);
		transcribedText.setFont(TEXT_FIELD_FONT);
		transcribedText.setEditable(true); // allows insertion tracker to appear
		presentedText.setBackground(Color.WHITE);
		transcribedText.setBackground(Color.WHITE);
		presentedText.setForeground(new Color(0, 0, 128));

		resultsArea = new JTextArea(9, 30);
		resultsArea.setFont(new Font("sansserif", Font.PLAIN, 18));
		resultsArea.setBackground((new JButton()).getBackground());
		resultsPane = new JOptionPane(resultsArea, JOptionPane.INFORMATION_MESSAGE);
		resultsPane.setFont(new Font("sansserif", Font.PLAIN, 18));
		resultsDialog = resultsPane.createDialog(this, "Information");

		// initialize Graffiti-related stuff

		stroke = new Point[MAX_SAMPLES];
		sampleCount = 0;
		strokeCount = 0;

		u = new Unistroke();
		if (entryMode.equals(GRAFFITI))
			; // default is Graffiti

		else if (entryMode.equals(UNISTROKES))
			u.setDictionary(Unistroke.UNISTROKES);

		else if (entryMode.equals(DIGITS))
			u.setDictionary(Unistroke.DIGITS);

		else if (entryMode.equals(CUSTOM))
		{
			showError("ERROR: Entry mode \'CUSTOM\' not supported!");
			System.exit(0);
		} else
		{
			showError("ERROR: Unknown entry mode: \'" + entryMode + "\'");
		}
		// doNewPhrase(); // output first phrase and get ready to do

		graffitiPanel = new PaintPanel(); // this is where the input occurs

		URL imageURL1 = GraffitiExperimentGui.class.getResource(GRAFFITI_IMAGE);
		graffitiImage = (new ImageIcon(imageURL1)).getImage();

		URL imageURL2 = GraffitiExperimentGui.class.getResource(UNISTROKES_IMAGE);
		unistrokesImage = (new ImageIcon(imageURL2)).getImage();

		// NOTE: Don't seem to need the MediaTracker, plus problem with MediaTracker
		// when executing from the jar file (image loads black!)
		/*
		 * MediaTracker mt = new MediaTracker(this); mt.addImage(graffitiImage, 0);
		 * mt.addImage(unistrokesImage, 1); try { mt.waitForAll(); } catch (InterruptedException e)
		 * { System.out.println("Error with media tracker loading/waiting for images!");
		 * System.exit(0); }
		 */

		ImagePanel imagePanel = null;
		if (entryMode.equals(GRAFFITI))
			imagePanel = new ImagePanel(graffitiImage, graffitiImage.getWidth(this), graffitiImage.getHeight(this));

		else if (entryMode.equals(UNISTROKES))
			imagePanel = new ImagePanel(unistrokesImage, unistrokesImage.getWidth(this), unistrokesImage
					.getHeight(this));

		// ImagePanel.setOpaque(false);

		begin = new JButton("Begin");
		begin.setFont(TEXT_FIELD_FONT);
		JPanel beginPanel = new JPanel();
		beginPanel.add(begin, SwingConstants.CENTER);
		begin.setMaximumSize(begin.getPreferredSize());

		enter = new JButton("Enter");
		enter.setFont(TEXT_FIELD_FONT);
		JPanel enterPanel = new JPanel();
		enterPanel.add(enter, SwingConstants.CENTER);
		enter.setMaximumSize(enter.getPreferredSize());

		// -------------
		// add listeners
		// -------------

		graffitiPanel.addMouseMotionListener(this);
		graffitiPanel.addMouseListener(this);
		begin.addActionListener(this);
		enter.addActionListener(this);

		// ------------------
		// arrange components
		// ------------------

		outerPanel = new JPanel();
		outerPanel.setLayout(new BorderLayout(10, 10));
		outerPanel.add(graffitiPanel, "Center");
		outerPanel.add(beginPanel, "West");
		outerPanel.add(enterPanel, "East");
		Border b1 = new EtchedBorder();
		Border b2 = BorderFactory.createEmptyBorder(5, 5, 5, 5);
		outerPanel.setBorder(new CompoundBorder(b1, b2));

		JPanel p1 = new JPanel();
		p1.setLayout(new BorderLayout());
		p1.add(outerPanel, "Center");
		if (showGestureSet && (entryMode.equals(GRAFFITI) || entryMode.equals(UNISTROKES)))
			p1.add(imagePanel, "South");
		p1.setBorder(BorderFactory.createEmptyBorder(25, 25, 25, 25));

		JPanel p2 = new JPanel();
		p2.setLayout(new BoxLayout(p2, BoxLayout.Y_AXIS));
		p2.add(Box.createRigidArea(new Dimension(0, 10)));
		p2.add(presentedText);
		p2.add(Box.createRigidArea(new Dimension(0, 10)));
		p2.add(transcribedText);
		p2.setBorder(BorderFactory.createEmptyBorder(25, 25, 25, 25));

		JPanel p3 = new JPanel(new BorderLayout());
		p3.add(p2, "North");
		p3.add(p1, "Center");

		this.setContentPane(p3);
		transcribedText.requestFocus();
	}

	private static void showError(String msg)
	{
		JOptionPane.showMessageDialog(null, msg, "I/O Error", JOptionPane.ERROR_MESSAGE);
	}

	public static String[] getDictionary(String fileArg)
	{
		// prepare to read the words from a disk file
		BufferedReader br = null;
		try
		{
			br = new BufferedReader(new FileReader(fileArg));
		} catch (FileNotFoundException e)
		{
			showError("File not found: " + fileArg);
			return null;
		}

		String line = null;
		Vector<String> v = new Vector<String>();
		StringTokenizer st;
		while (true)
		{
			try
			{
				line = br.readLine();
			} catch (IOException e)
			{
				showError("Error reading file: " + fileArg);
				return null;
			}

			if (line == null)
				break;

			if (line.length() == 0)
				continue;

			st = new StringTokenizer(line);

			// get the words
			while (st.hasMoreTokens())
				v.addElement(st.nextToken());
		}

		// initialize dictionary array with just the right amount of space
		String[] tmp = new String[v.size()];

		// copy elements from vector into array
		v.copyInto(tmp);

		// return a reference to the quotation array (whew!)
		return tmp;
	}

	public void gatherMeasurements()
	{
		++count;
		if (t1 == 0)
			t1 = System.currentTimeMillis();
		t2 = System.currentTimeMillis() - t1;
		samples.addElement(new Sample(t2, newKey.toLowerCase()));
	}

	// ------------------------
	// implement ActionListener
	// ------------------------
	public void actionPerformed(ActionEvent ae)
	{
		Object button = ae.getSource();
		if (button == begin)
		{
			doNewPhrase();
		} else if (button == enter)
		{
			doEndOfPhrase();
		}
	}

	// -----------------------------------------
	// implement MouseMotionListener methods (2)
	// -----------------------------------------

	// "inking"
	public void mouseDragged(MouseEvent me)
	{
		int x = me.getX();
		int y = me.getY();

		if (SwingUtilities.isLeftMouseButton(me))
		{
			stroke[sampleCount] = new Point(x, y);
			int x1 = (int)stroke[sampleCount - 1].getX();
			int y1 = (int)stroke[sampleCount - 1].getY();
			int x2 = (int)stroke[sampleCount].getX();
			int y2 = (int)stroke[sampleCount].getY();
			if (sampleCount < MAX_SAMPLES - 1)
				++sampleCount;
			graffitiPanel.drawInk(x1, y1, x2, y2);
		}
	}

	public void mouseMoved(MouseEvent me)
	{
	}

	// ------------------------------------
	// implements MouseListener methods (5)
	// ------------------------------------

	public void mouseClicked(MouseEvent me)
	{
	}

	public void mouseEntered(MouseEvent me)
	{
	}

	public void mouseExited(MouseEvent me)
	{
	}

	// a mouse button was pressed ("pen down")
	public void mousePressed(MouseEvent me)
	{
		int x = me.getX();
		int y = me.getY();
		stroke[sampleCount] = new Point(x, y);
		if (sampleCount < MAX_SAMPLES - 1)
			++sampleCount;
	}

	// a mouse button was released ("pen up")
	public void mouseReleased(MouseEvent me)
	{
		// int candidateIndex = -1;
		if (SwingUtilities.isLeftMouseButton(me))
		{
			String s = u.recognize(stroke, sampleCount);
			newKey = s;

			String xs = "x=,";
			String ys = "y=,";
			for (int i = 0; i < sampleCount; ++i)
			{
				xs += stroke[i].getX() + ",";
				ys += stroke[i].getY() + ",";
			}
			xs += "\n";
			ys += "\n";

			// write trace data to sd3 file
			try
			{
				sd3File.write(xs, 0, xs.length());
				sd3File.write(ys, 0, ys.length());
				sd3File.flush();
			} catch (IOException e)
			{
				showError("ERROR WRITING TO sd3 TRACE DATA FILE!\n" + e);
				System.exit(1);
			}

			// play appropriate sound clip
			if (s.equals("#"))
				playSound(unrecognizedClip);
			else
				playSound(recognizedClip);

			// process returned string, as appropriate
			if (s.equals("=E")) // SPACE
			{
				s = " "; // re-map

				/*
				 * // new code for spell checking String word = ""; for (int i =
				 * transcribedText.getText().length(); i > 0; --i) { char c =
				 * transcribedText.getText().charAt(i - 1); if (c != ' ') word = c + word; else
				 * break; } // System.out.print(word);
				 * 
				 * // String msd1 = ""; // String msd2 = ""; // String msd3 = ""; int count1 = 0;
				 * int count2 = 0; int count3 = 0; int n = Arrays.binarySearch(dict, word); if (n >=
				 * 0) { // System.out.println("Found! index: " + n); } else { for (int i = 0; i <
				 * dict.length; ++i) { int distance = (new MSD(dict[i], word)).getMSD(); if
				 * (Math.abs(dict[i].length() - word.length()) > 2) continue; if (distance == 1 &&
				 * count1 < 10) { // msd1 += dict[i] + " "; ++count1; } if (distance == 2 && count2
				 * < 10) { // msd2 += dict[i] + " "; ++count2; } if (distance == 3 && count3 < 10) {
				 * // msd3 += dict[i] + " "; ++count3; } } // System.out.println("Not found!");
				 * 
				 * // String list = msd1 + msd2 + msd3; // StringTokenizer st = new
				 * StringTokenizer(list); // System.out.print(" : "); // for (int i = 0; i < 10 &&
				 * st.hasMoreTokens(); ++i) // System.out.print(st.nextToken() + " "); } //
				 * System.out.println(); // end new code
				 */
			} else if (s.equals("=W")) // BACKSPACE
			{
				s = "";
				String tmp = transcribedText.getText();
				if (tmp.length() > 0)
					transcribedText.setText(tmp.substring(0, tmp.length() - 1));
			} else if (s.equals("#")) // un-recognized stroke
				s = "#"; // leave as is, for error correction
			else if (s.equals("=SW"))
			{
				s = "#"; // use unrecognized character
			} else if (s.equals("=TAP"))
			{
				tap = true;
				// candidateIndex = me.getY() / 25; // 25 = magic!
				s = "";
			} else if (s.charAt(0) == '=') // no-mapping for other straight line
											// strokes
				s = "";

			transcribedText.setText(transcribedText.getText() + s);

			++strokeCount;
			sampleCount = 0;
			gatherMeasurements();
			graffitiPanel.clear();
			tap = false;
		}
	}

	void doNewPhrase()
	{
		samples = new Vector<Sample>();
		String tmp = phrases[r.nextInt(phrases.length)];
		presentedText.setText(tmp);
		tm.clear();
		build = "";
		transcribedText.setText("");
		transcribedText.requestFocus();
		t1 = 0;
		count = 0;

		// write presented text phrase to sd3 file
		try
		{
			sd3File.write(tmp + "\n", 0, tmp.length() + 1);
			sd3File.flush();
		} catch (IOException e)
		{
			showError("ERROR WRITING TO sd3 TRACE DATA FILE!\n" + e);
			System.exit(1);
		}

		tm.clear();
		t1 = 0;
		count = 0;
		samples = new Vector<Sample>();
		return;
	}

	void doEndOfPhrase()
	{
		String s1 = presentedText.getText().toLowerCase().trim();
		String s2 = transcribedText.getText().toLowerCase().trim();

		MSD s1s2 = new MSD(s1, s2);
		int msd = s1s2.getMSD();

		// build formated results data to send to GUI
		String resultsString = "Thank you!\n\n";
		resultsString += String.format("Presented:\t%s\n", s1);
		resultsString += String.format("Transcribed:\t%s\n", s2);
		resultsString += String.format("Entry speed:\t%.2f wpm\n", wpm(s2, t2));
		resultsString += String.format("Error rate:\t%.2f%%\n", s1s2.getErrorRateNew());
		resultsString += String.format("KSPC:\t%.4f\n\n", (double)count / s2.length());
		resultsString += "Click OK to continue";
		resultsArea.setText(resultsString);
		resultsDialog.setVisible(true);

		// build output data for sd2 file
		String sd2Stuff = "GraffitiExperiment," + participantCode + "," + entryMode.toUpperCase() + "," + conditionCode
				+ "," + sessionCode + "," + blockCode + "," + count + ",";
		sd2Stuff += String.format("%d,", s2.length()); // number of characters entered
		sd2Stuff += String.format("%f,", t2 / 1000.0); // time (s)
		sd2Stuff += String.format("%d,", msd); // MSD
		sd2Stuff += String.format("%f,", wpm(s2, t2)); // entry speed (words per minute)
		sd2Stuff += String.format("%f,", s1s2.getErrorRateNew()); // error rate
		sd2Stuff += String.format("%f\n", (double)count / s2.length()); // KSPC (end of line too!)

		// build output data for sd1 file
		String sd1Stuff = s1 + "\n";
		sd1Stuff += s2 + "\n";
		for (int i = 0; i < samples.size(); ++i)
			sd1Stuff += samples.elementAt(i) + "\n";
		sd1Stuff += "#\n";

		// dump data to files
		try
		{
			sd1File.write(sd1Stuff, 0, sd1Stuff.length());
			sd1File.flush();
			sd2File.write(sd2Stuff, 0, sd2Stuff.length());
			sd2File.flush();
			sd3File.write(s2 + "\n-----\n", 0, s2.length() + 7);
			sd3File.flush();
		} catch (IOException e)
		{
			showError("ERROR WRITING TO DATA FILE!\n" + e);
			System.exit(1);
		}

		// check if last phrase in block
		if (--phraseCount == 0)
		{
			try
			{
				sd1File.close();
				sd2File.close();
				sd3File.close();
			} catch (IOException e)
			{
				showError("ERROR CLOSING DATA FILE!\n" + e);
				System.exit(1);
			}
			System.exit(0);
		} else
			doNewPhrase();
		return;
	}

	// compute typing speed in wpm given text entered and time in ms
	public static double wpm(String text, long msTime)
	{
		double speed = text.length();
		speed = speed / (msTime / 1000.0) * (60 / 5);
		return speed;
	}

	class ImagePanel extends JPanel
	{
		// the following avoids a "warning" with Java 1.5.0 complier (?)
		static final long serialVersionUID = 42L;
		Image image;
		int w, h;
		final int WIDTH = 400;
		final int HEIGHT = 100;

		public ImagePanel(Image imageArg, int widthArg, int heightArg)
		{
			image = imageArg;
			w = widthArg;
			h = heightArg;
			this.setBorder(BorderFactory.createLineBorder(Color.gray));
			this.setBackground(Color.WHITE);
			// this.setOpaque(true);
			this.setPreferredSize(new Dimension(WIDTH, HEIGHT));
		}

		@Override
		public void paintComponent(Graphics g)
		{
			super.paintComponent(g); // paint background
			int x = this.getWidth() / 2 - WIDTH / 2;
			g.drawImage(image, x, 0, WIDTH, HEIGHT, this); // draw image
		}
	}

	// -------------------------------------------------------
	// Sample - simple class to hold a timestamp and keystroke
	// -------------------------------------------------------

	private class Sample
	{
		private long time;
		private String key;

		Sample(long timeArg, String keyArg)
		{
			time = timeArg;
			key = keyArg;
		}

		@Override
		public String toString()
		{
			return time + ", " + key;
		}
	}

	// Initialize stream for sound clip
	public Clip initSound(String soundFile)
	{
		AudioInputStream audioInputStream;
		Clip c = null;
		try
		{
			// audioInputStream =
			// AudioSystem.getAudioInputStream(getClass().getResourceAsStream(soundFile));
			// dataLineInfo = new DataLine.Info(Clip.class, audioInputStream.getFormat());
			// c = (Clip)AudioSystem.getLine(dataLineInfo);
			// c.open(audioInputStream);
			// System.out.println(soundFile + ": " + dataLineInfo);

			// Added for executable Jar:
			audioInputStream = AudioSystem.getAudioInputStream(new BufferedInputStream(getClass().getResourceAsStream(
					soundFile)));
			c = AudioSystem.getClip();
			c.open(audioInputStream);
		} catch (Exception e)
		{
			showError("ERROR: Unable to load sound clip (" + soundFile + ")");
		}
		return c;
	}

	// play sound
	public void playSound(Clip c)
	{
		if (c != null)
		{
			c.setFramePosition(0); // rewind clip to beginning
			c.start(); // stops at end of clip
		}
	}

	// -------------------------------------------------
	// PaintPanel - a panel for drawing with digital ink
	// -------------------------------------------------

	class PaintPanel extends JPanel
	{
		// the following avoids a "warning" with Java 1.5.0 complier (?)
		static final long serialVersionUID = 42L;

		private final Color INK_COLOR = new Color(0, 0, 128);
		private final Stroke INK_STROKE = new BasicStroke(5.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
		private Vector<Line2D.Double> v;

		PaintPanel()
		{
			v = new Vector<Line2D.Double>();
			this.setBackground(Color.pink);
			this.setBorder(BorderFactory.createLineBorder(Color.gray));
			this.setPreferredSize(new Dimension(300, 200));
		}

		@Override
		public void paintComponent(Graphics g)
		{
			super.paintComponent(g);
			paintInkStrokes(g);
		}

		/**
		 * Paint all the line segments stored in the vector
		 */
		private void paintInkStrokes(Graphics g)
		{
			Graphics2D g2 = (Graphics2D)g;

			// set the inking color
			g2.setColor(INK_COLOR);

			// set the stroke thickness, and cap and join attributes ('round')
			Stroke s = g2.getStroke(); // save current stroke
			g2.setStroke(INK_STROKE); // set desired stroke

			// retrive each line segment and draw it
			for (int i = 0; i < v.size(); ++i)
				g2.draw(v.elementAt(i));

			g2.setStroke(s); // restore stroke
		}

		/**
		 * Draw one line segment, then add it to the vector
		 */
		public void drawInk(int x1, int y1, int x2, int y2)
		{
			// get graphics context
			Graphics2D g2 = (Graphics2D)this.getGraphics();

			// create the line
			Line2D.Double inkSegment = new Line2D.Double(x1, y1, x2, y2);

			g2.setColor(INK_COLOR); // set the inking color
			Stroke s = g2.getStroke(); // save current stroke
			g2.setStroke(INK_STROKE); // set desired stroke
			g2.draw(inkSegment); // draw it!
			g2.setStroke(s); // restore stroke
			v.add(inkSegment); // add to vector
		}

		public void clear()
		{
			v.clear();
			this.repaint();
		}
	}
}
